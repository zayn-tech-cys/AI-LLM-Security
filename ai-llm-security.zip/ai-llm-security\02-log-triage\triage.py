"""
AI-assisted SIEM log triage, with the accuracy claims kept honest.

    python triage.py            # all experiments
    python triage.py --quick    # smaller sample, faster

Three experiments:

  A. Leakage demo.  Predict the sensor's severity from the raw log *as given*,
     then again with the severity token scrubbed. The gap between the two
     numbers is the whole lesson.

  B. Triage model. A documented, rule-constructed "needs analyst attention"
     label, and four models compared on it. Scored against the rules that
     defined it -- explicitly not against verified reality.

  C. Failure analysis. Where the model is wrong, and why a high score here does
     not mean the model would catch an attack.
"""

from __future__ import annotations

import argparse
import json
import re
import time
from pathlib import Path

import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (accuracy_score, confusion_matrix, f1_score,
                             precision_score, recall_score)
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.svm import LinearSVC

from audit_data import audit, load, print_audit

HERE = Path(__file__).resolve().parent
RULE = "=" * 76

# ---------------------------------------------------------------------------
# Experiment B: the constructed triage label
# ---------------------------------------------------------------------------
#
# There is no verified ground truth here, so we construct one from documented,
# defensible rules and are explicit that accuracy is measured against the rules.
# Each rule below is a thing a real SOC triage playbook would plausibly contain.

TRIAGE_RULES = [
    # (name, test, weight)
    ("auth_failure_burst", r"\b(failed|denied|locked|invalid)\b", 3),
    ("privilege_change", r"\b(privilege|escalat|admin|root|sudo|grant)\b", 3),
    ("credential_access", r"\b(credential|password|token|api[_-]?key|secret)\b", 3),
    ("exfiltration_shape", r"\b(exfil|upload|transfer|dump|export)\b", 3),
    ("malware_signal", r"\b(malware|ransom|trojan|c2|beacon|callback)\b", 3),
    ("policy_bypass", r"\b(bypass|disabled|allow[_-]?all)\b", 2),
    ("data_access", r"\b(file_access|read|download|query)\b", 1),
]

# Threshold chosen so the positive rate lands in a realistic triage band
# (~10-20% of alerts warranting analyst attention). At 6 the rate was 0.9%,
# which made every model look either useless or degenerate.
TRIAGE_THRESHOLD = 3


def build_text(row: dict) -> str:
    """Flatten an event into the text the classifier sees.

    Deliberately excludes the raw CEF header, which carries the severity
    token. See `scrub_severity` for the leaky variant.
    """
    parts = [
        row.get("event_type") or "",
        row.get("source") or "",
        row.get("action") or "",
        row.get("description") or "",
        row.get("object") or "",
        row.get("parent_process") or "",
        row.get("alert_type") or "",
        row.get("category") or "",
        row.get("protocol") or "",
    ]
    return " ".join(p for p in parts if p)


def scrub_severity(row: dict) -> str:
    """Same as :func:`build_text` but keeps the raw log -- and so leaks.

    Included so Experiment A can measure exactly how much the leak is worth.
    """
    return f"{build_text(row)} {row.get('raw_log') or ''}"


def triage_label(row: dict) -> int:
    """Constructed label: does this event match the attention playbook?"""
    haystack = " ".join(
        str(row.get(f) or "")
        for f in ("event_type", "action", "description", "object",
                  "raw_log", "alert_type", "category")
    ).lower()
    score = sum(weight for _name, pattern, weight in TRIAGE_RULES
                if re.search(pattern, haystack))
    return int(score >= TRIAGE_THRESHOLD)


def majority_baseline(y_true: np.ndarray) -> float:
    """Accuracy of always predicting the most common class."""
    counts = np.bincount(y_true)
    return float(counts.max() / counts.sum())


# ---------------------------------------------------------------------------
# Models
# ---------------------------------------------------------------------------


def build_models() -> dict:
    """Four models spanning bag-of-words to bag-of-words plus structure."""
    return {
        "LogisticRegression": Pipeline([
            ("tfidf", TfidfVectorizer(max_features=40_000, ngram_range=(1, 2),
                                     sublinear_tf=True, min_df=2)),
            ("clf", LogisticRegression(max_iter=1000, C=4.0,
                                       class_weight="balanced")),
        ]),
        "LinearSVC": Pipeline([
            ("tfidf", TfidfVectorizer(max_features=40_000, ngram_range=(1, 2),
                                     sublinear_tf=True, min_df=2)),
            ("clf", LinearSVC(C=0.5, class_weight="balanced", max_iter=5000)),
        ]),
        "RandomForest": Pipeline([
            ("tfidf", TfidfVectorizer(max_features=20_000, ngram_range=(1, 1),
                                     sublinear_tf=True, min_df=3)),
            ("clf", RandomForestClassifier(n_estimators=200, max_depth=40,
                                           n_jobs=-1, class_weight="balanced",
                                           random_state=0)),
        ]),
        "NaiveBayes": Pipeline([
            ("tfidf", TfidfVectorizer(max_features=40_000, ngram_range=(1, 2),
                                     sublinear_tf=True, min_df=2)),
            ("clf", __import__("sklearn.naive_bayes", fromlist=["ComplementNB"])
             .ComplementNB()),
        ]),
    }


def evaluate(name: str, model, X_train, y_train, X_test, y_test) -> dict:
    started = time.perf_counter()
    model.fit(X_train, y_train)
    elapsed = time.perf_counter() - started
    predicted = model.predict(X_test)

    # Experiment A is multiclass (six severity levels); B and C are binary.
    # Macro averaging makes precision/recall/F1 comparable across both.
    multiclass = len(np.unique(y_test)) > 2
    average = "macro" if multiclass else "binary"
    kwargs = {} if multiclass else {"zero_division": 0}

    return {
        "model": name,
        "task": "multiclass" if multiclass else "binary",
        "average": average,
        "accuracy": accuracy_score(y_test, predicted),
        "precision": precision_score(y_test, predicted, average=average, **kwargs),
        "recall": recall_score(y_test, predicted, average=average, **kwargs),
        "f1": f1_score(y_test, predicted, average=average, **kwargs),
        "confusion": confusion_matrix(y_test, predicted).tolist(),
        "train_seconds": round(elapsed, 2),
    }


# ---------------------------------------------------------------------------
# Experiments
# ---------------------------------------------------------------------------


def experiment_a(rows: list[dict], seed: int) -> dict:
    """Show that the obvious task leaks its own answer."""
    text = [scrub_severity(r) for r in rows]           # leaky: contains the label
    labels = np.array([SEV_INDEX.get(r.get("severity"), 0) for r in rows])

    X_train, X_test, y_train, y_test = train_test_split(
        text, labels, test_size=0.25, random_state=seed, stratify=labels
    )

    leaky = Pipeline([
        ("tfidf", TfidfVectorizer(max_features=30_000, ngram_range=(1, 2),
                                 sublinear_tf=True)),
        ("clf", LinearSVC(max_iter=5000)),
    ])
    leaky_result = evaluate("leaky: severity present in raw_log", leaky,
                            X_train, y_train, X_test, y_test)

    # Now remove the leak: strip the CEF severity field from the raw log.
    def strip(text_row: str) -> str:
        return re.sub(r"\|(info|low|medium|high|critical|emergency)\|",
                      "|SEV|", text_row)

    clean = [strip(t) for t in text]
    X_train2, X_test2, y_train2, y_test2 = train_test_split(
        clean, labels, test_size=0.25, random_state=seed, stratify=labels
    )
    clean_model = Pipeline([
        ("tfidf", TfidfVectorizer(max_features=30_000, ngram_range=(1, 2),
                                 sublinear_tf=True)),
        ("clf", LinearSVC(max_iter=5000)),
    ])
    clean_result = evaluate("scrubbed: severity token removed", clean_model,
                            X_train2, y_train2, X_test2, y_test2)

    baseline = majority_baseline(y_test)
    return {
        "leaky": leaky_result,
        "scrubbed": clean_result,
        "majority_baseline": baseline,
        "leak_worth": leaky_result["accuracy"] - clean_result["accuracy"],
    }


SEV_INDEX = {"info": 0, "low": 1, "medium": 2, "high": 3,
             "critical": 4, "emergency": 5}


def experiment_b(rows: list[dict], seed: int, limit: int = 25_000) -> dict:
    """Triage model against the constructed label."""
    subset = rows[:limit]
    text = [build_text(r) for r in subset]
    labels = np.array([triage_label(r) for r in subset])

    X_train, X_test, y_train, y_test = train_test_split(
        text, labels, test_size=0.25, random_state=seed, stratify=labels
    )
    results = [evaluate(name, model, X_train, y_train, X_test, y_test)
               for name, model in build_models().items()]
    baseline = majority_baseline(y_test)
    return {
        "results": sorted(results, key=lambda r: r["f1"], reverse=True),
        "baseline": baseline,
        "positive_rate": float(labels.mean()),
        "n": len(subset),
        "y_test": y_test,
    }


def experiment_c(rows: list[dict], seed: int, limit: int = 25_000) -> dict:
    """Probe the constructed label for the failure that matters.

    If the label can be predicted from `event_type` alone, then the "model" is
    learning the rules I wrote by reading the same keywords they key on, and has
    learned nothing a triage playbook would not already tell you.
    """
    subset = rows[:limit]
    event_types = np.array([r.get("event_type") or "unknown" for r in subset])
    labels = np.array([triage_label(r) for r in subset])
    X_train, X_test, y_train, y_test = train_test_split(
        event_types, labels, test_size=0.25, random_state=seed, stratify=labels
    )
    model = Pipeline([
        ("onehot", TfidfVectorizer(analyzer="char", ngram_range=(1, 32))),
        ("clf", LogisticRegression(max_iter=1000, class_weight="balanced")),
    ])
    result = evaluate("event_type only", model, X_train, y_train, X_test, y_test)

    # And the reverse: how much of the label survives if we hide every keyword
    # the rules key on?
    #
    # The redaction must not itself leak. Replacing each match with a distinct
    # token left the *number* of REDACTED tokens as a near-perfect predictor of
    # the label -- the rules fire on presence, so counting redactions recovers
    # the answer. Collapse them to a single shared token so presence is gone
    # and only count is not available either.
    stripped = []
    for row in subset:
        t = build_text(row)
        for _name, pattern, _w in TRIAGE_RULES:
            t = re.sub(pattern, "X", t, flags=re.I)
        stripped.append(re.sub(r"\bX(\s+X\b)+", "X", t))
    Xtr, Xte, ytr, yte = train_test_split(
        stripped, labels, test_size=0.25, random_state=seed, stratify=labels
    )
    hidden = evaluate("all rule keywords redacted",
                      Pipeline([("tfidf", TfidfVectorizer(max_features=30_000,
                                                         sublinear_tf=True)),
                                ("clf", LinearSVC(max_iter=5000))]),
                      Xtr, ytr, Xte, yte)
    return {"event_type_only": result, "keywords_redacted": hidden,
            "baseline": majority_baseline(y_test)}


# ---------------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------------


def print_experiment_a(result: dict) -> None:
    print("\n" + RULE)
    print("EXPERIMENT A  Does the obvious task leak its own answer?")
    print(RULE)
    print("  task: predict the sensor's severity from the raw log")
    print()
    print(f"  {result['leaky']['model']}")
    print(f"      accuracy {result['leaky']['accuracy']:.1%}   "
          f"F1 {result['leaky']['f1']:.1%}")
    print()
    print(f"  {result['scrubbed']['model']}")
    print(f"      accuracy {result['scrubbed']['accuracy']:.1%}   "
          f"F1 {result['scrubbed']['f1']:.1%}")
    print()
    print(f"  majority-class baseline   {result['majority_baseline']:.1%}")
    print(f"  accuracy attributable to the leak: "
          f"{result['leak_worth']:+.1%} points")
    print()
    print("  The first number is what you get if you never look at your data.")
    print("  The second is what the model can actually learn here.")


def print_experiment_b(result: dict) -> None:
    print("\n" + RULE)
    print("EXPERIMENT B  Triage model, four ways")
    print(RULE)
    print(f"  rows {result['n']:,}   positive rate {result['positive_rate']:.1%}")
    print(f"  majority-class baseline accuracy: {result['baseline']:.1%}")
    print()
    header = f"  {'MODEL':<22}{'PREC':>8}{'RECALL':>9}{'F1':>8}{'ACC':>8}{'TRAIN S':>10}"
    print(header)
    print("  " + "-" * (len(header) - 2))
    for row in result["results"]:
        print(f"  {row['model']:<22}{row['precision']:>8.3f}{row['recall']:>9.3f}"
              f"{row['f1']:>8.3f}{row['accuracy']:>8.3f}{row['train_seconds']:>10.1f}")
    print()
    print("  PRECISION is the number an SOC cares about: of the alerts it would")
    print("  escalate, how many should have been escalated. Recall says how much")
    print("  of the playbook the model covers.")
    print()
    print("  All of these are measured against the RULE-DEFINED label, not")
    print("  against verified attacks. See the README before quoting any of them.")


def print_experiment_c(result: dict) -> None:
    print("\n" + RULE)
    print("EXPERIMENT C  What the triage model is really doing")
    print(RULE)
    et = result["event_type_only"]
    kr = result["keywords_redacted"]
    print(f"  event type alone, no text     F1 {et['f1']:.3f}  acc {et['accuracy']:.3f}")
    print(f"  every rule keyword redacted   F1 {kr['f1']:.3f}  acc {kr['accuracy']:.3f}")
    print(f"  majority-class baseline       acc {result['baseline']:.3f}")
    print()
    print("  If event type alone scores well, the model is reading the same")
    print("  keywords my own rules key on. It has learned my rules, not security.")
    print()
    print("  The honest conclusion: on this data a triage classifier reproduces")
    print("  the playbook that defined its own labels. That is a useful sanity")
    print("  check and it is NOT evidence of detection capability.")


def main() -> int:
    parser = argparse.ArgumentParser(description="AI-assisted SIEM log triage")
    parser.add_argument("--quick", action="store_true",
                        help="use 15,000 rows instead of 60,000")
    parser.add_argument("--skip-audit", action="store_true",
                        help="skip the data audit")
    parser.add_argument("--json", metavar="FILE", help="write results as JSON")
    args = parser.parse_args()

    print(RULE)
    print("AI-ASSISTED SIEM LOG TRIAGE")
    print("Dataset: darkknight25/Advanced_SIEM_Dataset (Microsoft Sentinel events)")
    print(RULE)

    rows = load(15_000 if args.quick else 60_000)
    print(f"loaded {len(rows):,} events")

    if not args.skip_audit:
        print_audit(audit(rows))

    a = experiment_a(rows, seed=42)
    print_experiment_a(a)

    b = experiment_b(rows, seed=42, limit=15_000 if args.quick else 25_000)
    print_experiment_b(b)

    c = experiment_c(rows, seed=42, limit=15_000 if args.quick else 25_000)
    print_experiment_c(c)

    print("\n" + RULE)
    print("HOW TO USE THIS OUTPUT")
    print(RULE)
    print("  The triage ranking is usable. The accuracy figures are not a claim")
    print("  that these events contain attacks, because nothing in the dataset")
    print("  says they do. Treat the scores as 'agreement with a documented")
    print("  playbook', which is what they measure.")
    print()
    print("  For a real deployment, replace the constructed label with verified")
    print("  incident data, and re-measure. The audit script will tell you")
    print("  whether that dataset is fit for purpose.")

    if args.json:
        payload = {
            "experiment_a_leakage": {k: v for k, v in a.items()},
            "experiment_b_triage": {k: v for k, v in b.items() if k != "y_test"},
            "experiment_c_probe": c,
        }
        (HERE / args.json).write_text(json.dumps(payload, indent=2), encoding="utf-8")
        print(f"\n  results written to {HERE / args.json}")

    print()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())