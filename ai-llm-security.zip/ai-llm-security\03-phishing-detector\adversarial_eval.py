"""
Where the phishing classifier actually fails.

`train.py` reports 0.96-0.98 F1. That number is measured on the distribution the
model was trained on, whose "phishing" class is bulk spam. This file measures the
thing you actually care about: does the model flag a *credential-phishing*
email, and does it leave legitimate business mail alone?

The test set below is hand-authored for this project. Every email is fictional,
and none of them shares vocabulary with the training corpus beyond ordinary
English. That is the point -- the training set never contained a well-written
business email asking for a login, which is the hardest real case.

    python adversarial_eval.py
    python adversarial_eval.py --show-errors
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from sklearn.metrics import (accuracy_score, confusion_matrix, f1_score,
                             precision_score, recall_score)

from train import (build_classical_models, load, normalise_subject)
from sklearn.model_selection import train_test_split

HERE = Path(__file__).resolve().parent
RULE = "=" * 76

# ---------------------------------------------------------------------------
# Adversarial set: realistic credential phishing. Label 1.
# These are the emails a SOC actually worries about.
# ---------------------------------------------------------------------------

CREDENTIAL_PHISHING = [
    "Subject: Action required: mailbox quota exceeded\n\n"
    "Your mailbox has reached 95% of its storage limit and will be suspended "
    "within 48 hours. You can avoid this by confirming your credentials through "
    "the secure portal below. You will be asked for your corporate username and "
    "password, followed by the six-digit code sent to your phone.\n\n"
    "Confirm now: http://mailbox-verify.acmecorp-support.co/entrance\n\n"
    "IT Service Desk",

    "Subject: Your account has been flagged\n\n"
    "Dear Colleague,\n\nWe have identified unusual activity on your account "
    "during the last 24 hours. For your protection, access has been "
    "suspended.\n\n"
    "To restore access within 30 minutes you must re-authenticate using the "
    "link below. Failure to do so will result in permanent closure.\n\n"
    "http://acmecorp-support.co/restore?id=88213\n\n"
    "Security Team",

    "Subject: Updated payroll details required before 5pm\n\n"
    "Hi,\n\nFollowing the merger, payroll is being migrated to a new provider. "
    "Records that are not updated will be paid at the previous rate.\n\n"
    "Please review and confirm your bank details here: "
    "https://hr-payroll-update.co/confirm\n\n"
    "Thanks,\nPayroll",

    "Subject: Shared document: Q4 forecast (final).xlsx\n\n"
    "Sarah Whitfield has shared a document with you.\n\n"
    "Review the attached forecast before Thursday. If the figures look wrong, "
    "use the comments form to request access to the editable version.\n\n"
    "Open document: http://share.acmecorp-docs.co/q4-forecast\n\n"
    "Microsoft 365",

    "Subject: Fwd: Re: supplier payment - URGENT\n\n"
    "Can you action this today please? I'm about to board a flight.\n\n"
    ">> Sarah Whitfield wrote:\n>> They need the payment cleared before close "
    "of business or we lose the discount. New bank details are on the thread.\n\n"
    "Pay here: acmecorp.group/pay/vendor9931",

    "Subject: Sign in to continue to the shared folder\n\n"
    "You have been invited to a folder in SharePoint. You must sign in with your "
    "work account to accept the invitation.\n\n"
    "Accept invitation: https://acmecorp.sharepoint-access.co/accept\n\n"
    "This link expires in 2 hours.",

    "Subject: Security alert: unusual device detected\n\n"
    "A sign-in was detected from an unrecognised device in Bucharest, Romania. "
    "If this was not you, secure your account immediately.\n\n"
    "Secure my account: http://acme-login-verify.co/secure\n\n"
    "Do not share this notification with anyone, including IT support.",

    "Subject: Mandatory MFA re-enrolment\n\n"
    "Due to a security audit all staff must re-enrol multi-factor "
    "authentication by Friday.\n\n"
    "You will need your password and a code from your authenticator. "
    "Complete enrolment here: https://acmecorp-mfa-setup.co/enrol\n\n"
    "IT Helpdesk, ext. 4471",

    "Subject: Re: invoice overdue - final notice\n\n"
    "Our records show invoice INV-20241 remains unpaid. The account will be "
    "referred to collections and late fees added.\n\n"
    "Settle now: acmecorp.com/pay/inv-20241\n\n"
    "Accounts Receivable",

    "Subject: Your benefits enrolment is incomplete\n\n"
    "You have 2 days left to confirm your pension and healthcare elections. "
    "Failure to complete this means you will receive the default package.\n\n"
    "Log in to complete: https://benefits.acmecorp-portal.co/login\n\n"
    "People Operations",

    "Subject: CEO wants you to review before 6pm\n\n"
    "Jim has asked if you can pick up the vendor payment review. He's in the "
    "board meeting. Can you sign off on the attached change request?\n\n"
    "Review and approve: acmecorp.org/approvals/pending/8821\n\n"
    "Sent from my mobile",

    "Subject: Your session will expire in 10 minutes\n\n"
    "For your security, you will be signed out. Re-authenticate to continue "
    "working. Enter your username, password and the verification code from "
    "your mobile to keep your session active.\n\n"
    "Stay signed in: https://acmecorp-sso.co/auth/refresh",

    "Subject: Attachment: revised-overtime.xlsx\n\n"
    "Please open the attached spreadsheet and sign in with your work "
    "credentials to download it. The file is hosted on our secure document "
    "service.\n\n"
    "http://acmecorp-docs.co/files/revised-overtime.xlsx",

    "Subject: Verify your business email to avoid delivery suspension\n\n"
    "We have detected that your domain may be sending on behalf of an "
    "unverified sender. Verify ownership now to protect your mail flow.\n\n"
    "Verify domain: http://mail-verify.acmecorp.co/domain\n\n"
    "Mail Delivery Team",

    "Subject: Password expires today\n\n"
    "Your network password expires at 18:00 today. To keep working, confirm "
    "your current password and set a new one through the portal. You will also "
    "be asked to approve a mobile push notification.\n\n"
    "Change password: https://acmecorp-nw.co/password",

    "Subject: Payroll direct deposit change - action needed\n\n"
    "HR need to confirm a change to your direct deposit before the next pay "
    "run. Verify your identity by entering your payroll number, current bank "
    "details and the new account.\n\n"
    "Confirm now: acmecorp.co/hr/directdeposit/confirm",

    "Subject: Shared OneDrive folder with 4 new files\n\n"
    "A folder has been shared with you by IT Service Desk. You must sign in to "
    "view the files.\n\n"
    "https://acmecorp-onedrive.co/folders/shared/992\n\n"
    "Do not forward this email.",

    "Subject: Legal hold notice - do not delete\n\n"
    "This mailbox is now under legal hold. Do not delete any messages. "
    "Confirm receipt by signing in to the compliance portal with your work "
    "credentials.\n\n"
    "Acknowledge: https://acmecorp-compliance.co/acknowledge",
]

# ---------------------------------------------------------------------------
# Adversarial set: legitimate business email. Label 0.
# The hard case -- professional, long, full of URLs, and must NOT be flagged.
# ---------------------------------------------------------------------------

BENIGN_BUSINESS = [
    "Subject: Re: Q3 forecast - revised assumptions\n\n"
    "Hi,\n\nThanks for sending this through. I've updated the revenue "
    "assumptions to reflect the revised churn figure of 4.2% and pulled the "
    "Q3 hiring plan into the model. Comments are inline on the forecast tab.\n\n"
    "One query on the infrastructure line -- do you want that at the current "
    "run rate or annualised? Let me know and I'll re-run before Thursday.\n\n"
    "Best,\nDaniel\n\n-- \nDaniel Okafor\nHead of Procurement\nT +44 20 7946 0958",

    "Subject: Meeting notes - platform steering committee\n\n"
    "All,\n\nNotes from today's steering committee below. Key decisions: we are "
    "going ahead with the staged migration in week 34, the vendor has "
    "confirmed the support window, and we will review the risk register "
    "fortnightly until sign-off.\n\n"
    "Actions: Daniel to confirm the hardware order by Friday; Priya to circulate "
    "the revised RACI; I'll book the next slot.\n\n"
    "Thanks,\nMarcus\n\n"
    "This email and any attachments are confidential and intended solely for "
    "the named recipient. If you have received this in error, please notify the "
    "sender and delete it. Please note that Acme Corporation monitors all "
    "electronic communications on its systems for security and compliance "
    "purposes, and content may be retained or reviewed in accordance with the "
    "company Acceptable Use Policy. This automated message was generated by the "
    "Microsoft Exchange server and cannot receive replies.",

    "Subject: Your annual leave request has been approved\n\n"
    "Hi,\n\nYour leave request for 14-18 April has been approved by your line "
    "manager. Your calendar has been updated and the cover arrangements for "
    "the period are confirmed with the team.\n\n"
    "Anything outstanding before you go, please hand over by Friday. Enjoy the "
    "break.\n\n"
    "People Operations",

    "Subject: Security bulletin: phishing campaign targeting our supplier\n\n"
    "All,\n\nOver the weekend our security team blocked a targeted phishing "
    "campaign impersonating our payroll provider. Nineteen staff received it; "
    "nobody submitted credentials.\n\n"
    "The messages asked recipients to confirm bank details through a portal on a "
    "look-alike domain. If you received one, delete it and report via the "
    "Report Phishing button in Outlook. Do not reply to the sender.\n\n"
    "Reminders: we will never ask you to confirm bank details by email, and we "
    "will never ask for your password or a one-time code. Report, do not "
    "investigate.\n\n"
    "Security Team",

    "Subject: Contract renewal - Greenfield Supplies Ltd\n\n"
    "Morning,\n\nThe renewal paperwork for Greenfield is with legal. Two points "
    "to flag before signature: the liability cap has been raised from 12 months "
    "to 24, and they have moved the payment terms to 60 days from invoice, which "
    "is better than our current 30.\n\n"
    "I've attached the redline and the summary from the last review. Can you "
    "review the commercial terms by Wednesday?\n\n"
    "Thanks,\nSarah",

    "Subject: Office move - access arrangements\n\n"
    "Hi all,\n\nWe move to the fourth floor on Saturday between 18:00 and "
    "22:00. Desk moves have been assigned and are listed on the noticeboard.\n\n"
    "Badges need reissuing for the new floor - bring your current badge to "
    "reception on Friday afternoon. Server room access is unchanged.\n\n"
    "Facilities",

    "Subject: Re: Re: supplier payment - URGENT\n\n"
    "Morning,\n\nNo, I can't action that from this thread. Bank detail changes "
    "need the callback procedure regardless of who asks, and I'd rather lose the "
    "discount than skip it.\n\n"
    "Give me a ring on the number we have on file and I'll do it then.\n\n"
    "Sarah",

    "Subject: Quarterly access review - action for line managers\n\n"
    "All,\n\nThe quarterly access review opens Monday. Line managers need to "
    "confirm the privileged accounts on their teams are still required, and "
    "remove anyone who has left or changed role.\n\n"
    "The form takes about ten minutes per team. Deadline is the end of the "
    "month.\n\n"
    "IT Security",

    "Subject: Lunch and learn - threat intelligence briefing\n\n"
    "The threat intel team are running a session on the current intrusion set "
    "activity we're seeing. Thursday, 12:30, room 2.04. Lunch provided.\n\n"
    "No preparation needed, though reading the monthly bulletin beforehand "
    "helps.\n\n"
    "Security Team",

    "Subject: Your order has shipped\n\n"
    "Good news - your order is on its way.\n\n"
    "Order: AC-88213\nCourier: Parcelforce\nTracking: "
    "https://www.parcelforce.com/track/AC88213GB\n\n"
    "Estimated delivery: tomorrow before 18:00. You don't need to do anything.",

    "Subject: Building works - water will be off Thursday\n\n"
    "Water will be off between 09:00 and 13:00 on Thursday while the tanks are "
    "replaced. There will be no supply to the kitchen or the washrooms.\n\n"
    "Servers are unaffected and the data centre has independent supply. There "
    "is no need to shut anything down.\n\n"
    "Facilities",

    "Subject: Re: headcount plan H2\n\n"
    "Thanks for the draft. Two thoughts: the second tranche in September looks "
    "early given the budget review isn't until October, and I'd rather protect "
    "the platform team than the growth pod.\n\n"
    "Happy to walk through it live if that's easier.\n\n"
    "Priya",

    "Subject: Quarterly results and dividend\n\n"
    "Dear Shareholder,\n\nThe results for the quarter are attached, along with "
    "the statement from the chair.\n\n"
    "Revenue grew 6% on the prior period, driven by services. The board has "
    "declared an interim dividend of 4.2p per share, payable on 28 March to "
    "shareholders on the register at close on 14 March.\n\n"
    "The full results are available on the investor relations page of our "
    "website.\n\n"
    "Acme Corporation plc\nRegistered in England and Wales, number 4471020\n"
    "Registered office: 1 Example Street, London EC1A 1AA",

    "Subject: Re: laptop refresh - order confirmation\n\n"
    "Confirmed, order placed. 34 units, standard config, delivery expected "
    "week 38.\n\n"
    "One question: two of the replacements are for the lab, which is out of the "
    "standard build. Do you want those ordered separately?\n\n"
    "Thanks,\nDaniel",

    "Subject: Mandatory training deadline extended\n\n"
    "The deadline for the annual information security module has moved from the "
    "15th to the 30th. Nothing else changes and no new content has been added.\n\n"
    "If you've already completed it, nothing to do.\n\n"
    "Learning and Development",

    "Subject: Re: customer escalation - Meridian Group\n\n"
    "Spoke to their IT lead this morning. The issue is a certificate on their "
    "side that expired over the weekend. They're regenerating it and will retry "
    "tonight.\n\n"
    "I'd suggest we hold the release until we see it succeed rather than "
    "expediting and hoping. Let me know what you prefer.\n\n"
    "Marcus",

    "Subject: New starter - IT setup completed\n\n"
    "Confirmed setup is complete for the starter in the finance team starting "
    "Monday: laptop, account, mailbox, MFA token, and access to the shared "
    "drives they need.\n\n"
    "They'll need to collect the badge on their first day.\n\n"
    "IT Service Desk",

    "Subject: Password change reminder\n\n"
    "Your network password expires in 7 days. You can change it yourself via "
    "the self-service portal at https://selfservice.acmecorp.co/password\n\n"
    "If you have any trouble, raise a ticket and we'll help. Please do not "
    "contact anyone outside the company for assistance with passwords.",

    "Subject: Team lunch Friday - please confirm\n\n"
    "Booking a table for 12:30 on Friday. Let me know by Wednesday so I can "
    "give the restaurant final numbers.\n\n"
    "There's a veggie and a vegan option this time, and the menu has a gluten "
    "free section.\n\n"
    "Marcus",
]


def evaluate(models, X_test_texts, y_test, adversarial_texts, adv_labels):
    """Score each model on both the in-distribution and adversarial sets."""
    rows = []
    for name, model in models.items():
        in_dist_pred = model.predict(X_test_texts)
        adv_pred = model.predict(adversarial_texts)
        rows.append({
            "model": name,
            "in_distribution": {
                "precision": precision_score(y_test, in_dist_pred, zero_division=0),
                "recall": recall_score(y_test, in_dist_pred, zero_division=0),
                "f1": f1_score(y_test, in_dist_pred, zero_division=0),
                "accuracy": accuracy_score(y_test, in_dist_pred),
            },
            "adversarial": {
                "precision": precision_score(adv_labels, adv_pred, zero_division=0),
                "recall": recall_score(adv_labels, adv_pred, zero_division=0),
                "f1": f1_score(adv_labels, adv_pred, zero_division=0),
                "accuracy": accuracy_score(adv_labels, adv_pred),
            },
            "confusion": confusion_matrix(adv_labels, adv_pred).tolist(),
        })
    return rows


def main() -> int:
    parser = argparse.ArgumentParser(description="Adversarial evaluation")
    parser.add_argument("--rows", type=int, default=12_000)
    parser.add_argument("--show-errors", action="store_true",
                        help="print the emails the model got wrong")
    parser.add_argument("--json", default="adversarial_results.json")
    args = parser.parse_args()

    print(RULE)
    print("ADVERSARIAL EVALUATION - what the F1 number is actually worth")
    print(RULE)

    adversarial_texts = [normalise_subject(t) for t in
                         CREDENTIAL_PHISHING + BENIGN_BUSINESS]
    adv_labels = np.array([1] * len(CREDENTIAL_PHISHING) +
                          [0] * len(BENIGN_BUSINESS))

    print(f"\nadversarial set: {len(CREDENTIAL_PHISHING)} credential-phishing "
          f"(label 1)\n                {len(BENIGN_BUSINESS)} legitimate business "
          f"(label 0)")
    print("none of these share the spam vocabulary of the training corpus")

    texts, labels = load(args.rows)
    X_train, X_test, y_train, y_test = train_test_split(
        texts, labels, test_size=0.2, random_state=42, stratify=labels
    )
    print(f"training corpus: {len(texts):,} emails, positive rate "
          f"{labels.mean():.1%}")

    models = build_classical_models()
    for model in models.values():
        model.fit(X_train, y_train)

    rows = evaluate(models, X_test, y_test, adversarial_texts, adv_labels)

    print("\n" + RULE)
    print("RESULTS")
    print(RULE)
    header = (f"  {'MODEL':<22}"
              f"{'IN-DIST F1':>11}{'ADV PREC':>10}{'ADV REC':>9}"
              f"{'ADV F1':>8}{'DROP':>7}")
    print(header)
    print("  " + "-" * (len(header) - 2))
    for row in sorted(rows, key=lambda r: r["adversarial"]["f1"], reverse=True):
        in_f1 = row["in_distribution"]["f1"]
        adv_f1 = row["adversarial"]["f1"]
        print(f"  {row['model']:<22}{in_f1:>11.3f}"
              f"{row['adversarial']['precision']:>10.3f}"
              f"{row['adversarial']['recall']:>9.3f}"
              f"{adv_f1:>8.3f}{in_f1 - adv_f1:>7.3f}")
    print("\n  PRECISION on the adversarial set is the false-positive rate on real")
    print("  business mail. RECALL is the miss rate on real credential phishing.")
    print("  A model with high precision and zero recall flags nothing but never")
    print("  catches anything, which is worse than useless in a mail filter.")

    best = max(rows, key=lambda r: r["adversarial"]["f1"])
    print(f"\n  best adversarial performer: {best['model']}")
    print(f"  confusion [[tn fp][fn tp]] = {best['confusion']}")
    print(f"    false positives (business mail flagged):   {best['confusion'][0][1]}")
    print(f"    false negatives (phishing not flagged):   {best['confusion'][1][0]}")

    if args.show_errors:
        model = models[best["model"]]
        predicted = model.predict(adversarial_texts)
        print("\n" + RULE)
        print("MISCLASSIFICATIONS")
        print(RULE)
        for index, (text, truth, pred) in enumerate(
                zip(CREDENTIAL_PHISHING + BENIGN_BUSINESS, adv_labels, predicted)):
            if truth == pred:
                continue
            kind = "PHISHING missed" if truth == 1 else "BUSINESS MAIL flagged"
            snippet = text[:150].replace("\n", " ")
            print(f"\n  [{kind}] {snippet}...")

    (HERE / args.json).write_text(
        json.dumps({"adversarial_rows": rows}, indent=2, default=float),
        encoding="utf-8")

    print("\n" + RULE)
    print("CONCLUSION")
    print(RULE)
    print("  The in-distribution score and the adversarial score are different")
    print("  measurements of different things. Only the second one answers the")
    print("  question a mail filter is actually deployed to answer.")
    print()
    print("  A model tuned on this corpus is a spam filter. It is not a phishing")
    print("  filter, and reporting its accuracy as phishing detection performance")
    print("  is the most common way this kind of result gets oversold.")
    print()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())