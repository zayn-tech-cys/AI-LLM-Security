﻿"""Shared helpers for the AI/LLM security suite."""
