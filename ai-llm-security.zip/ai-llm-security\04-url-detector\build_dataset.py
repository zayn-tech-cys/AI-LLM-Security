"""
Build a labelled URL set from live public sources, then train and evaluate.

    python build_dataset.py     # fetch malicious + benign URLs
    python train.py             # features, models, honest evaluation
    python train.py --inspect <url>   # feature dump for one URL

Sources
-------
Malicious   URLhaus (abuse.ch) recent feed        -- real, live
            OpenPhish community feed                -- real, live
Benign      a curated list of widely-used sites     -- hand-maintained

Caveat that matters: the malicious feeds are dominated by *malware* and
*botnet* URLs, not credential phishing. Same problem as project 03, and it is
stated in the README and measured in the results rather than glossed over.
"""

from __future__ import annotations

import argparse
import csv
import io
import json
import urllib.request
from pathlib import Path

HERE = Path(__file__).resolve().parent
DATA_DIR = HERE / "data"
URL_FILE = DATA_DIR / "urls.json"
RULE = "=" * 76

URLHAUS_CSV = "https://urlhaus.abuse.ch/downloads/csv_recent/"
OPENPHISH = "https://openphish.com/feed.txt"
PHISHING_DB = ("https://raw.githubusercontent.com/mitchellkrogza/"
               "Phishing.Database/master/phishing-domains-ACTIVE.txt")

# Well-known sites, used as the benign class. Curated rather than scraped so the
# set is stable and the labels are obviously correct.
BENIGN_SEEDS = [
    "https://www.google.com/", "https://www.youtube.com/", "https://www.wikipedia.org/",
    "https://github.com/", "https://stackoverflow.com/", "https://python.org/",
    "https://docs.python.org/", "https://www.bbc.co.uk/news", "https://www.nhs.uk/",
    "https://www.gov.uk/", "https://www.amazon.co.uk/", "https://www.tesco.com/",
    "https://www.sainsburys.co.uk/", "https://www.microsoft.com/", "https://support.apple.com/",
    "https://developer.apple.com/", "https://docs.aws.amazon.com/", "https://cloud.google.com/",
    "https://pypi.org/", "https://numpy.org/", "https://pandas.pydata.org/",
    "https://scikit-learn.org/", "https://www.postgresql.org/", "https://redis.io/",
    "https://nginx.org/", "https://www.linuxfoundation.org/", "https://ubuntu.com/",
    "https://debian.org/", "https://www.mozilla.org/", "https://www.rfc-editor.org/",
    "https://datatracker.ietf.org/", "https://www.nist.gov/", "https://cisa.gov/",
    "https://arxiv.org/", "https://www.researchgate.net/", "https://scholar.google.com/",
    "https://en.wikipedia.org/wiki/Main_Page", "https://www.reuters.com/",
    "https://www.theguardian.com/", "https://www.ft.com/", "https://www.bbc.com/news",
    "https://openai.com/", "https://www.anthropic.com/", "https://huggingface.co/",
    "https://www.kaggle.com/", "https://stackoverflow.com/questions",
    "https://en.cppreference.com/w/", "https://www.cplusplus.com/",
]

# Common benign paths and query patterns, so the benign class is not trivially
# all bare domains -- otherwise the model learns "has a path = phishing".
BENIGN_VARIANTS = [
    "{base}/about", "{base}/pricing", "{base}/docs/getting-started",
    "{base}/help?topic=billing", "{base}/blog/2026/01/release-notes",
    "{base}/en/contact", "{base}/legal/terms", "{base}/account/settings",
    "{base}/products/list?page=2", "{base}/news/2026/02/updates",
    "{base}/search?q=security+training", "{base}/status",
]


def fetch(url: str, timeout: int = 45) -> bytes:
    request = urllib.request.Request(url, headers={"User-Agent": "lab/1.0"})
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return response.read()


def fetch_urlhaus(limit: int) -> list[str]:
    """Malware/botnet URLs from URLhaus.

    Two things about this dump that both silently produce zero rows:

    1. It opens with a ``#`` comment banner, so DictReader takes the first
       comment line as the header and every column comes back as ``None``.
    2. After stripping the banner there is **no header row at all** -- the file
       is positional data. So DictReader is the wrong tool entirely: the URL is
       simply the third column.

    Parsed positionally, which is what the format actually is.
    """
    out: list[str] = []
    try:
        raw = fetch(URLHAUS_CSV).decode("utf-8", "replace")
    except Exception as exc:
        print(f"  urlhaus unavailable: {exc}")
        return out
    body = "\n".join(line for line in raw.splitlines()
                     if not line.lstrip().startswith("#"))
    reader = csv.reader(io.StringIO(body))
    for row in reader:
        if len(row) < 3:
            continue
        url = row[2].strip()
        if url.startswith("http"):
            out.append(url)
        if len(out) >= limit:
            break
    return out


def fetch_phishing_db(limit: int) -> list[str]:
    """Active phishing domains from the community Phishing.Database."""
    out: list[str] = []
    try:
        raw = fetch(PHISHING_DB).decode("utf-8", "replace")
    except Exception as exc:
        print(f"  phishing.database unavailable: {exc}")
        return out
    for line in raw.splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "." in line:
            out.append(f"http://{line}/")
        if len(out) >= limit:
            break
    return out


def fetch_openphish(limit: int) -> list[str]:
    """Credential-phishing URLs from OpenPhish."""
    out: list[str] = []
    try:
        raw = fetch(OPENPHISH).decode("utf-8", "replace")
    except Exception as exc:
        print(f"  openphish unavailable: {exc}")
        return out
    for line in raw.splitlines():
        line = line.strip()
        if line.startswith("http"):
            out.append(line)
        if len(out) >= limit:
            break
    return out


def build(malicious_per_source: int = 700) -> dict:
    print("fetching live feeds ...")
    malware = fetch_urlhaus(malicious_per_source)
    phishing = fetch_openphish(malicious_per_source)
    extra = fetch_phishing_db(malicious_per_source)
    print(f"  urlhaus             {len(malware):,} URLs")
    print(f"  openphish           {len(phishing):,} URLs")
    print(f"  phishing.database   {len(extra):,} URLs")

    urls: list[dict] = []
    seen: set[str] = set()
    for url in malware:
        if url not in seen:
            seen.add(url)
            urls.append({"url": url, "label": 1, "source": "urlhaus"})
    for url in phishing:
        if url not in seen:
            seen.add(url)
            urls.append({"url": url, "label": 1, "source": "openphish"})
    for url in extra:
        if url not in seen:
            seen.add(url)
            urls.append({"url": url, "label": 1, "source": "phishing_db"})

    for base in BENIGN_SEEDS:
        for template in BENIGN_VARIANTS[:4]:
            url = template.format(base=base.rstrip("/"))
            if url not in seen:
                seen.add(url)
                urls.append({"url": url, "label": 0, "source": "curated_benign"})
        if base not in seen:
            seen.add(base)
            urls.append({"url": base, "label": 0, "source": "curated_benign"})

    DATA_DIR.mkdir(parents=True, exist_ok=True)
    URL_FILE.write_text(json.dumps(urls, indent=0), encoding="utf-8")
    malicious = sum(u["label"] for u in urls)
    stats = {
        "total": len(urls),
        "malicious": malicious,
        "benign": len(urls) - malicious,
        "from_urlhaus": sum(1 for u in urls if u["source"] == "urlhaus"),
        "from_openphish": sum(1 for u in urls if u["source"] == "openphish"),
        "from_phishing_db": sum(1 for u in urls if u["source"] == "phishing_db"),
        "benign_curated": sum(1 for u in urls if u["source"] == "curated_benign"),
    }
    return stats


def load() -> list[dict]:
    if not URL_FILE.exists():
        return []
    return json.loads(URL_FILE.read_text(encoding="utf-8"))


def main() -> int:
    parser = argparse.ArgumentParser(description="Build the labelled URL set")
    parser.add_argument("--per-source", type=int, default=700)
    args = parser.parse_args()

    print(RULE)
    print("BUILDING URL DATASET")
    print(RULE)
    stats = build(args.per_source)
    print()
    for key, value in stats.items():
        print(f"  {key:<22} {value:,}")
    print(f"\nwritten to {URL_FILE}")
    print("\nNOTE: urlhaus is mostly malware distribution; openphish is credential")
    print("phishing. They are kept separate in the 'source' field so the mix can")
    print("be controlled and reported on.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())