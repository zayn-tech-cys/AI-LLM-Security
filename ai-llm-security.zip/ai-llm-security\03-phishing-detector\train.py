"""
Phishing email classification on a public corpus, with the label problem
addressed head-on.

    python train.py              # full comparison, all models
    python train.py --quick      # 6,000 rows, skips the transformer
    python adversarial_eval.py   # where the winner actually fails

Dataset
-------
`zefang-liu/phishing-email-dataset` (HuggingFace), 18,650 labelled emails:
11,322 "Safe Email" and 7,328 "Phishing Email".

The label caveat, which is the most important thing in this project
-------------------------------------------------------------------
The two classes are **bulk spam** and **normal email**, not *credential
phishing* and *legitimate business email*. Inspecting samples: the "Safe" class
is Enron business and personal mail; the "Phishing" class is overwhelmingly
advance-fee and adult spam ("Hello I am your hot lil horny toy", Nigerian
prince). Neither class resembles a targeted business email compromise.

So a high score here means **"this model separates bulk spam from ordinary
email"**. It does not mean the model would catch a credential-phishing email,
and it very much does not mean it would catch a well-written spearphish.

`adversarial_eval.py` measures exactly that gap on a held-out set of realistic
credential phishing and benign business email that share no vocabulary with the
training corpus.
"""

from __future__ import annotations

import argparse
import csv
import json
import re
import sys
import time
import urllib.request
from pathlib import Path

import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (accuracy_score, classification_report, confusion_matrix,
                             f1_score, precision_score, recall_score)
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import ComplementNB, MultinomialNB
from sklearn.pipeline import Pipeline
from sklearn.svm import LinearSVC
from sklearn.ensemble import RandomForestClassifier

HERE = Path(__file__).resolve().parent
DATA_DIR = HERE / "data"
DATA_FILE = DATA_DIR / "Phishing_Email.csv"
DATASET_URL = ("https://huggingface.co/datasets/zefang-liu/"
               "phishing-email-dataset/resolve/main/Phishing_Email.csv")
RULE = "=" * 76

PHISHING = "Phishing Email"
SAFE = "Safe Email"

# Some rows carry megabyte-scale blobs. Truncating keeps training tractable and
# removes a length artefact that would otherwise dominate every model.
MAX_CHARS = 20_000


def ensure_data() -> Path:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    if DATA_FILE.exists() and DATA_FILE.stat().st_size > 1_000_000:
        return DATA_FILE
    print("downloading zefang-liu/phishing-email-dataset (~50 MB, once) ...", flush=True)
    urllib.request.urlretrieve(DATASET_URL, DATA_FILE)
    return DATA_FILE


def normalise_subject(text: str) -> str:
    """Lowercase, strip addresses and URLs.

    Addresses and URLs are the strongest artefact in this corpus -- the spam
    class is full of them and the ham class is not. Leaving them in means every
    model scores well by memorising "has a URL" rather than by reading English.
    """
    text = re.sub(r"https?://\S+", " URL ", text)
    text = re.sub(r"www\.\S+", " URL ", text)
    text = re.sub(r"\b[\w.+-]+@[\w.-]+\.\w+\b", " EMAIL ", text)
    text = re.sub(r"\s+", " ", text)
    return text.strip().lower()


def load(max_rows: int | None = None) -> tuple[list[str], np.ndarray]:
    """Load the corpus as (normalised text, labels 0=safe 1=phishing)."""
    path = ensure_data()
    csv.field_size_limit(2_000_000_000)
    texts: list[str] = []
    labels: list[int] = []
    with path.open(encoding="utf-8", errors="replace", newline="") as handle:
        for row in csv.DictReader(handle):
            kind = (row.get("Email Type") or "").strip()
            if kind not in (PHISHING, SAFE):
                continue
            body = (row.get("Email Text") or "")[:MAX_CHARS]
            if len(body.strip()) < 10:
                continue
            texts.append(normalise_subject(body))
            labels.append(1 if kind == PHISHING else 0)
            if max_rows and len(texts) >= max_rows:
                break
    return texts, np.array(labels)


def build_classical_models() -> dict:
    """Four classical models, all on the same TF-IDF representation."""
    return {
        "MultinomialNB": Pipeline([
            ("tfidf", TfidfVectorizer(max_features=60_000, ngram_range=(1, 2),
                                     sublinear_tf=True, min_df=2)),
            ("clf", MultinomialNB(alpha=0.1)),
        ]),
        "ComplementNB": Pipeline([
            ("tfidf", TfidfVectorizer(max_features=60_000, ngram_range=(1, 2),
                                     sublinear_tf=True, min_df=2)),
            ("clf", ComplementNB(alpha=0.1)),
        ]),
        "LogisticRegression": Pipeline([
            ("tfidf", TfidfVectorizer(max_features=60_000, ngram_range=(1, 2),
                                     sublinear_tf=True, min_df=2)),
            ("clf", LogisticRegression(max_iter=2000, C=4.0,
                                       class_weight="balanced")),
        ]),
        "LinearSVC": Pipeline([
            ("tfidf", TfidfVectorizer(max_features=60_000, ngram_range=(1, 2),
                                     sublinear_tf=True, min_df=2)),
            ("clf", LinearSVC(C=0.5, class_weight="balanced", max_iter=5000)),
        ]),
        "RandomForest": Pipeline([
            ("tfidf", TfidfVectorizer(max_features=20_000, ngram_range=(1, 1),
                                     sublinear_tf=True, min_df=3)),
            ("clf", RandomForestClassifier(n_estimators=300, max_depth=50,
                                           n_jobs=-1, class_weight="balanced",
                                           random_state=0)),
        ]),
    }


def build_transformer(model_name: str = "distilbert-base-uncased",
                      epochs: int = 1, max_len: int = 256):
    """Fine-tune a small pretrained transformer. Slow on CPU; optional.

    Returns None if torch or transformers is unavailable, so the suite still
    runs without them.
    """
    try:
        import torch
        from torch.utils.data import DataLoader, Dataset
        from transformers import (AutoModelForSequenceClassification,
                                  AutoTokenizer)
    except ImportError:
        print("  torch/transformers not installed; skipping the transformer",
              file=sys.stderr)
        return None

    torch.manual_seed(0)
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    model = AutoModelForSequenceClassification.from_pretrained(
        model_name, num_labels=2)

    class _DS(Dataset):
        def __init__(self, texts, labels):
            self.enc = tokenizer(list(texts), truncation=True,
                                padding="max_length", max_length=max_len)
            self.labels = list(labels)

        def __len__(self):
            return len(self.labels)

        def __getitem__(self, i):
            item = {k: torch.tensor(v[i]) for k, v in self.enc.items()}
            item["labels"] = torch.tensor(self.labels[i])
            return item

    optimiser = torch.optim.AdamW(model.parameters(), lr=3e-5)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.to(device)

    class _Wrapper:
        name = f"Transformer ({model_name.split('/')[-1]})"
        device = device
        tokenizer = tokenizer
        max_len = max_len

        def __init__(self, core, epochs):
            self.core = core
            self.epochs = epochs

        def fit(self, texts, labels):
            loader = DataLoader(_DS(texts, labels), batch_size=16, shuffle=True)
            self.core.train()
            for epoch in range(self.epochs):
                total = 0.0
                for batch in loader:
                    batch = {k: v.to(device) for k, v in batch.items()}
                    output = self.core(**batch)
                    output.loss.backward()
                    optimiser.step()
                    optimiser.zero_grad()
                    total += float(output.loss)
                print(f"    epoch {epoch + 1}/{self.epochs}  "
                      f"loss {total / max(1, len(loader)):.4f}", flush=True)
            return self

        def predict(self, texts):
            self.core.eval()
            out = []
            with torch.no_grad():
                for start in range(0, len(texts), 32):
                    chunk = list(texts[start:start + 32])
                    enc = self.tokenizer(chunk, truncation=True, padding=True,
                                         max_length=self.max_len,
                                         return_tensors="pt").to(device)
                    out.extend(self.core(**enc).logits.argmax(-1).tolist())
            return np.array(out)

    return _Wrapper(model, epochs)


def score(name: str, y_pred: np.ndarray, train_seconds: float) -> dict:
    """Metrics plus predictions, so the winner can be profiled later.

    ``y_test`` is closed over rather than passed: every model is scored against
    the same held-out set and threading it through five call sites only created
    a chance to pass the wrong one.
    """
    y_true = _HELD_OUT["y_test"]
    return {
        "model": name,
        "accuracy": accuracy_score(y_true, y_pred),
        "precision": precision_score(y_true, y_pred, zero_division=0),
        "recall": recall_score(y_true, y_pred, zero_division=0),
        "f1": f1_score(y_true, y_pred, zero_division=0),
        "confusion": confusion_matrix(y_true, y_pred).tolist(),
        "train_seconds": round(train_seconds, 1),
        "_y_pred": y_pred,
    }


# Set once, after the split. Populated in main().
_HELD_OUT: dict = {}


def main() -> int:
    parser = argparse.ArgumentParser(description="Phishing email classifier comparison")
    parser.add_argument("--quick", action="store_true",
                        help="6,000 rows and no transformer")
    parser.add_argument("--rows", type=int, default=0,
                        help="cap rows (0 = all)")
    parser.add_argument("--transformer", default="distilbert-base-uncased")
    parser.add_argument("--no-transformer", action="store_true")
    parser.add_argument("--json", default="results.json")
    args = parser.parse_args()

    print(RULE)
    print("PHISHING EMAIL CLASSIFICATION - model comparison")
    print("Dataset: zefang-liu/phishing-email-dataset (18,650 labelled emails)")
    print(RULE)

    cap = args.rows or (6_000 if args.quick else 0)
    texts, labels = load(cap or None)
    print(f"\nloaded {len(texts):,} emails  "
          f"({labels.sum():,} phishing / {(1 - labels).sum():,} safe)")
    print(f"positive rate: {labels.mean():.1%}")
    print("\nLABEL CAVEAT: the 'phishing' class is bulk spam -- advance-fee and")
    print("adult mail -- and the 'safe' class is Enron business/personal mail.")
    print("Neither is credential phishing. See README before quoting any score.")

    X_train, X_test, y_train, y_test = train_test_split(
        texts, labels, test_size=0.2, random_state=42, stratify=labels
    )
    print(f"train {len(X_train):,}   test {len(X_test):,}")
    _HELD_OUT["y_test"] = y_test

    results = []
    print("\ntraining classical models ...")
    for name, model in build_classical_models().items():
        started = time.perf_counter()
        model.fit(X_train, y_train)
        elapsed = time.perf_counter() - started
        predicted = model.predict(X_test)
        results.append(score(name, predicted, elapsed))
        print(f"  {name:<22} done in {elapsed:>5.1f}s")

    if not args.no_transformer and not args.quick:
        print(f"\ntraining transformer ({args.transformer}) on CPU; this is slow ...")
        wrapper = build_transformer(args.transformer, epochs=1)
        if wrapper is not None:
            started = time.perf_counter()
            wrapper.fit(X_train, y_train)
            elapsed = time.perf_counter() - started
            predicted = wrapper.predict(X_test)
            results.append(score(wrapper.name, predicted, elapsed))

    results.sort(key=lambda r: r["f1"], reverse=True)

    print("\n" + RULE)
    print("RESULTS")
    print(RULE)
    header = f"  {'MODEL':<26}{'PREC':>7}{'RECALL':>8}{'F1':>7}{'ACC':>7}{'SECS':>8}"
    print(header)
    print("  " + "-" * (len(header) - 2))
    for row in results:
        print(f"  {row['model']:<26}{row['precision']:>7.3f}{row['recall']:>8.3f}"
              f"{row['f1']:>7.3f}{row['accuracy']:>7.3f}{row['train_seconds']:>8.1f}")

    print(f"\n  majority-class baseline accuracy: "
          f"{max((1 - labels).mean(), labels.mean()):.3f}")
    print("\n  per-class detail for the winner:")
    best = results[0]
    print(classification_report(_HELD_OUT["y_test"], best["_y_pred"],
                                target_names=["safe", "phishing"],
                                digits=3, zero_division=0))
    print(f"  confusion matrix [[tn fp],[fn tp]] = {best['confusion']}")

    serialisable = [{k: v for k, v in row.items()
                     if not k.startswith("_")} for row in results]
    (HERE / args.json).write_text(
        json.dumps({"n": len(texts), "results": serialisable}, indent=2),
        encoding="utf-8")

    print("\n" + RULE)
    print("WHAT THESE NUMBERS DO AND DO NOT MEAN")
    print(RULE)
    print("  DO mean: which model separates bulk spam from ordinary email best.")
    print("  DO NOT mean: any of these would catch a credential-phishing email.")
    print("  Run adversarial_eval.py to see the size of that gap, measured.")
    print()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())