"""
Run the injection lab: attack the vulnerable app, then attack the hardened one,
then attribute the improvement to individual defences.

    python run_lab.py                # full report
    python run_lab.py --verbose      # show each exchange
    python run_lab.py --json out.json

Every number printed comes from a run performed in this process. Nothing is
hardcoded.
"""

from __future__ import annotations

import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app import VulnerableAssistant
from attacks import ALL_ATTACKS, DIRECT, INDIRECT, OBFUSCATED, OWASP_LLM_TOP_10, coverage
from defenses import HardenedAssistant

RULE = "=" * 78


# ---------------------------------------------------------------------------
# Running attacks
# ---------------------------------------------------------------------------


def uses_poison(attack) -> bool:
    """Should the poisoned corpus be available for this attack?

    Indirect injection *is* the poison, so it needs it. Every other kind is
    tested against a clean corpus so the measurement is of the attacker's own
    payload rather than of a poisoned document that happened to be retrieved
    next to it. Without this split, any question that happens to retrieve a
    poisoned document triggers the document's own instruction override and the
    individual attack is never actually evaluated.
    """
    return attack.kind == "indirect"


def run_against_vulnerable(verbose: bool = False) -> list[dict]:
    """Every attack, against the undefended application."""
    rows: list[dict] = []
    for attack in ALL_ATTACKS:
        assistant = VulnerableAssistant()
        turn = assistant.ask(attack.payload, include_poisoned=uses_poison(attack))
        ok = attack.success(turn.response)
        bad = attack.compromised(turn.response)
        rows.append({
            "id": attack.attack_id,
            "name": attack.name,
            "kind": attack.kind,
            "goal": attack.goal,
            "owasp": list(attack.owasp),
            "succeeded": ok,
            "compromised": bad,
            "obeyed": turn.response.obeyed_injection,
            "leaked": turn.response.leaked_secret,
            "tool": turn.response.invoked_tool,
            "poisoned_retrieved": turn.retrieved_poisoned,
            "citations": [c.doc_id for c in turn.citations],
            "excerpt": turn.response.text[:110].replace("\n", " "),
        })
        if verbose:
            flag = "COMPROMISED" if ok else "resisted"
            print(f"    [{flag}] {attack.attack_id} {attack.name}")
            print(f"      poisoned retrieved: {turn.retrieved_poisoned}")
            print(f"      -> {turn.response.text[:150]}")
    return rows


def run_against_hardened(verbose: bool = False) -> list[dict]:
    """Every attack, against the full defence stack."""
    rows: list[dict] = []
    for attack in ALL_ATTACKS:
        assistant = HardenedAssistant()
        turn = assistant.ask(attack.payload, include_poisoned=uses_poison(attack))
        ok = attack.success(turn.response, executed_filter=turn.blocked)
        bad = attack.compromised(turn.response) and not turn.blocked
        rows.append({
            "id": attack.attack_id,
            "name": attack.name,
            "kind": attack.kind,
            "goal": attack.goal,
            "succeeded": ok,
            "compromised": bad,
            "blocked_by_filter": turn.blocked,
            "block_reason": turn.block_reason,
            "obeyed": turn.response.obeyed_injection,
            "leaked": turn.response.leaked_secret,
            "tool": turn.response.invoked_tool,
            "excerpt": turn.response.text[:110].replace("\n", " "),
        })
        if verbose:
            flag = "COMPROMISED" if ok else "resisted"
            print(f"    [{flag}] {attack.attack_id} {attack.name}"
                  f"{' (blocked at input)' if turn.blocked else ''}")
            print(f"      -> {turn.response.text[:150]}")
    return rows


def run_defence_attribution() -> list[dict]:
    """Enable defences one at a time to see which layer does the work.

    This is the measurement that matters: it shows the intuitive defence
    (keyword filtering) is the weakest, and that the structural ones are what
    actually hold.
    """
    layers = [
        ("none (vulnerable)", dict(use_input_filter=False, use_sanitiser=False,
                                   use_isolation=False, use_output_guard=False,
                                   use_privileges=False)),
        ("+ input filter only", dict(use_input_filter=True, use_sanitiser=False,
                                     use_isolation=False, use_output_guard=False,
                                     use_privileges=False)),
        ("+ retrieval sanitiser", dict(use_input_filter=True, use_sanitiser=True,
                                       use_isolation=False, use_output_guard=False,
                                       use_privileges=False)),
        ("+ prompt isolation", dict(use_input_filter=True, use_sanitiser=True,
                                    use_isolation=True, use_output_guard=False,
                                    use_privileges=False)),
        ("+ output guard", dict(use_input_filter=True, use_sanitiser=True,
                                use_isolation=True, use_output_guard=True,
                                use_privileges=False)),
        ("+ privilege separation (all)", dict(use_input_filter=True, use_sanitiser=True,
                                              use_isolation=True, use_output_guard=True,
                                              use_privileges=True)),
    ]

    rows = []
    for label, flags in layers:
        successes = 0
        tool_calls = 0
        for attack in ALL_ATTACKS:
            assistant = HardenedAssistant(**flags)
            turn = assistant.ask(attack.payload, include_poisoned=uses_poison(attack))
            if attack.success(turn.response, executed_filter=turn.blocked):
                successes += 1
            if attack.goal == "induce_tool_call" and turn.response.invoked_tool:
                tool_calls += 1
        total = len(ALL_ATTACKS)
        rows.append({
            "configuration": label,
            "attacks": total,
            "succeeded": successes,
            "success_rate": f"{successes / total:.0%}",
            "blocked": total - successes,
            "actionable_tool_calls": tool_calls,
        })
    return rows


def filter_bypass_analysis(vulnerable_rows: list[dict],
                           hardened_rows: list[dict]) -> dict:
    """Of the attacks that worked undefended, what actually stopped each one?

    Isolates the finding that the filter is the weakest layer, rather than
    asserting it. Attacks stopped by a structural layer rather than the filter
    are counted separately, because "the filter did not stop it" and "nothing
    stopped it" are very different results.
    """
    by_id = {r["id"]: r for r in hardened_rows}
    worked = [r for r in vulnerable_rows if r["succeeded"] or r["compromised"]]
    stopped_by_filter = []
    stopped_by_later_layer = []
    got_through = []
    for row in worked:
        hardened = by_id.get(row["id"], {})
        if hardened.get("succeeded") or hardened.get("compromised"):
            got_through.append(row["id"])
        elif hardened.get("blocked_by_filter"):
            stopped_by_filter.append(row["id"])
        else:
            stopped_by_later_layer.append(row["id"])
    return {
        "compromised_undefended": len(worked),
        "stopped_by_input_filter": len(stopped_by_filter),
        "stopped_by_structural_layer": len(stopped_by_later_layer),
        "reached_the_model": len(got_through),
        "filter_ids": stopped_by_filter,
        "structural_ids": stopped_by_later_layer,
        "through_ids": got_through,
        "filter_share": (
            round(len(stopped_by_filter) / len(worked), 2) if worked else 0.0
        ),
    }


# ---------------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------------


def print_header(title: str) -> None:
    print()
    print(RULE)
    print(title)
    print(RULE)


def print_table(rows: list[dict], columns: list[tuple[str, str, int]]) -> None:
    """columns: (key, header, width)."""
    header = "  ".join(h.ljust(w) for _, h, w in columns)
    print(header)
    print("-" * len(header))
    for row in rows:
        cells = []
        for key, _, width in columns:
            value = row.get(key, "")
            if isinstance(value, bool):
                value = "YES" if value else "."
            elif isinstance(value, list):
                value = ",".join(map(str, value)) or "-"
            cells.append(str(value)[:width].ljust(width))
        print("  ".join(cells))


def main() -> int:
    parser = argparse.ArgumentParser(description="LLM prompt injection lab")
    parser.add_argument("--verbose", "-v", action="store_true",
                        help="print every exchange")
    parser.add_argument("--json", metavar="FILE", help="also write results as JSON")
    args = parser.parse_args()

    print(RULE)
    print("LLM PROMPT INJECTION LAB")
    print("Target: RAG assistant over a policy-document corpus")
    print("Backend: deterministic instruction interpreter (no API key required)")
    print(f"Attacks: {len(ALL_ATTACKS)} "
          f"({len(DIRECT)} direct, {len(OBFUSCATED)} obfuscated/social, "
          f"{len(INDIRECT)} indirect)")
    print(RULE)

    print_header("PHASE 1  Undefended application")
    vulnerable = run_against_vulnerable(args.verbose)
    v_success = sum(r["succeeded"] for r in vulnerable)
    print_table(vulnerable, [
        ("id", "ID", 5),
        ("kind", "KIND", 12),
        ("name", "ATTACK", 40),
        ("compromised", "COMPROMISED", 12),
        ("succeeded", "GOAL MET", 9),
        ("tool", "TOOL", 18),
    ])
    print()
    v_bad = sum(r["compromised"] for r in vulnerable)
    print(f"  goal achieved          : {v_success}/{len(vulnerable)}  "
          f"({v_success / len(vulnerable):.0%})")
    print(f"  app compromised at all : {v_bad}/{len(vulnerable)}  "
          f"({v_bad / len(vulnerable):.0%})")
    print(f"  secrets leaked         : {sum(r['leaked'] for r in vulnerable)}")
    print(f"  actions induced        : {sum(1 for r in vulnerable if r['tool'])}")

    print_header("PHASE 2  Which layer stops what")
    attribution = run_defence_attribution()
    print_table(attribution, [
        ("configuration", "CONFIGURATION", 32),
        ("succeeded", "ATTACKS SUCCEEDED", 16),
        ("success_rate", "SUCCESS RATE", 12),
        ("blocked", "BLOCKED", 8),
        ("actionable_tool_calls", "ACTIONS", 8),
    ])

    print_header("PHASE 3  Hardened application")
    hardened = run_against_hardened(args.verbose)
    h_success = sum(r["succeeded"] for r in hardened)
    print_table(hardened, [
        ("id", "ID", 5),
        ("name", "ATTACK", 40),
        ("compromised", "COMPROMISED", 12),
        ("succeeded", "GOAL MET", 9),
        ("blocked_by_filter", "FILTERED", 9),
        ("leaked", "LEAKED", 7),
    ])
    print()
    h_bad = sum(r["compromised"] for r in hardened)
    print(f"  goal achieved          : {h_success}/{len(hardened)}  "
          f"({h_success / len(hardened):.0%})")
    print(f"  app compromised at all : {h_bad}/{len(hardened)}  "
          f"({h_bad / len(hardened):.0%})")
    print(f"  stopped at the filter  : "
          f"{sum(1 for r in hardened if r['blocked_by_filter'])}")
    print(f"  secrets that escaped  : {sum(r['leaked'] for r in hardened)}")

    print_header("PHASE 4  Which layer actually stopped what")
    analysis = filter_bypass_analysis(vulnerable, hardened)
    print(f"  attacks that compromised the undefended app : "
          f"{analysis['compromised_undefended']}")
    print(f"    stopped by the keyword filter             : "
          f"{analysis['stopped_by_input_filter']}  ({analysis['filter_share']:.0%})")
    print(f"      {analysis['filter_ids']}")
    print(f"    stopped by a structural layer instead      : "
          f"{analysis['stopped_by_structural_layer']}")
    print(f"      {analysis['structural_ids']}")
    print(f"    still reached the model                    : "
          f"{analysis['reached_the_model']}")
    print(f"      {analysis['through_ids']}")
    print()
    print("  Read that as: the filter stops roughly half of what worked. The rest")
    print("  needed the sanitiser, the isolation wrapper, the output guard or the")
    print("  privilege separation. Those layers are the defence, not the filter.")

    print_header("OWASP TOP 10 FOR LLM APPLICATIONS - COVERAGE")
    cov = coverage()
    for category in sorted(OWASP_LLM_TOP_10):
        hits = cov.get(category, [])
        mark = "exercised" if hits else "not exercised"
        print(f"  {category}  {OWASP_LLM_TOP_10[category]:<38} {mark}"
              f"  {','.join(hits)}")

    print_header("SUMMARY")
    print(f"  attacks                          {len(ALL_ATTACKS)}")
    print(f"  succeeded, undefended            {v_success}  ({v_success/len(ALL_ATTACKS):.0%})")
    print(f"  succeeded, fully defended        {h_success}  ({h_success/len(ALL_ATTACKS):.0%})")
    print(f"  attacks needing obfuscation only {sum(1 for a in OBFUSCATED if a.kind=='obfuscated')}")
    print(f"  indirect attacks (user innocent) {len(INDIRECT)}")
    print()
    print("  The headline: the undefended application is fully compromised by")
    print("  every attack class tried. The defended one is not, and the reason is")
    print("  the structural layers, not the filter.")

    if args.json:
        payload = {
            "attacks": len(ALL_ATTACKS),
            "vulnerable": vulnerable,
            "hardened": hardened,
            "defence_attribution": attribution,
            "filter_analysis": analysis,
            "owasp_coverage": {k: sorted(v) for k, v in cov.items()},
            "vulnerable_successes": v_success,
            "hardened_successes": h_success,
        }
        with open(args.json, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, indent=2)
        print(f"\n  results written to {args.json}")

    print()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())