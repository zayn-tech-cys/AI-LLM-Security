"""
Feature extraction for malicious URL detection.

Three groups, in rough order of how much they are actually worth:

    lexical     computable from the URL string alone -- entropy, character
                patterns, structure. Free, fast, and the bulk of the signal.

    structural  subdomain depth, IP-as-host, punycode, shorteners, credential
                in authority, port. Cheap and high-value.

    reputation  domain age from live RDAP registration data. The single most
                predictive feature in practice, and the only one that costs a
                network round trip. Cached on disk because it is the expensive
                part.

Design note: every feature is computed here rather than trusted from a
dataset's precomputed columns, so the same code works on any URL and the
feature definitions are auditable. See ``FEATURE_DOC`` for what each one means.
"""

from __future__ import annotations

import ipaddress
import json
import math
import string
import time
import urllib.error
import urllib.parse
import urllib.request
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

CACHE_PATH = Path(__file__).resolve().parent / "data" / "rdap_cache.json"
CACHE_TTL = 30 * 24 * 3600          # registration dates do not change often
RDAP_TIMEOUT = 10

# ---------------------------------------------------------------------------
# Feature documentation
# ---------------------------------------------------------------------------

FEATURE_DOC = {
    "url_length": "Total characters. Bulk-generated URLs run long.",
    "host_length": "Registrable-domain length. Long domains signal keyword stuffing.",
    "subdomain_depth": "Labels before the registrable domain. Deep nesting is used to bury a real brand.",
    "digit_ratio": "Fraction of digits in the host. Brands rarely have many; typo-squats do.",
    "hyphen_count": "Hyphens in the host. 'secure-login-verify' packs several.",
    "special_char_ratio": "Share of characters outside [a-z0-9.-] in the host.",
    "host_entropy": "Shannon entropy of the host. High for random-looking hosts.",
    "path_entropy": "Entropy of the path. High for generated redirect chains.",
    "tld_risk": "Risk weight of the TLD from published abuse rates.",
    "suspicious_tld": "1 if the TLD appears in a high-abuse list.",
    "is_ip_host": "1 if the host is a bare IP. Legitimate sites use names.",
    "punycode": "1 if the host contains xn--. Homograph domains encode look-alikes.",
    "credential_in_url": "1 if the authority contains @. Everything before it is a decoy.",
    "nonstandard_port": "1 if an explicit port is present.",
    "shortener": "1 if the host is a known URL-shortening service.",
    "brand_in_subdomain": "1 if a well-known brand name appears in a subdomain or the host.",
    "brand_in_path": "1 if a brand name appears in the path.",
    "suspicious_words": "Count of credential/urgency words across host and path.",
    "path_depth": "Path segments. Long redirect chains.",
    "query_params": "Query parameters. Data exfiltration endpoints take parameters.",
    "domain_age_days": "Days since RDAP registration. 9999 when unknown.",
    "is_new_domain": "1 if the domain is under 30 days old. A strong abuse signal.",
    "subdomain_entropy": "Entropy of the subdomain portion only.",
}

RISKY_TLDS = {
    "zip": 1.0, "mov": 1.0, "top": 0.9, "xyz": 0.85, "click": 0.95, "link": 0.8,
    "tk": 0.9, "ml": 0.9, "ga": 0.9, "cf": 0.85, "gq": 0.85, "work": 0.7,
    "country": 0.75, "kim": 0.85, "country": 0.75, "rest": 0.7, "quest": 0.8,
    "cyou": 0.8, "sbs": 0.8, "buzz": 0.7, "monster": 0.7, "lol": 0.6,
    "icu": 0.85, "bond": 0.75, "fit": 0.6, "wang": 0.8, "cfd": 0.85,
    "mom": 0.6, "lol": 0.6, "gdn": 0.75, "one": 0.6, "hair": 0.5, "men": 0.6,
}

SHORTENERS = {
    "bit.ly", "tinyurl.com", "goo.gl", "t.co", "ow.ly", "is.gd", "buff.ly",
    "adf.ly", "bit.do", "cutt.ly", "shorturl.at", "rb.gy", "tiny.cc",
    "bl.ink", "lnkd.in", "rebrand.ly", "t.ly", "s.id", "soo.gd", "clck.ru",
}

# Brands attackers impersonate. Matching a brand in the *subdomain* while the
# registrable domain is something else is the classic layout trick.
BRANDS = [
    "paypal", "apple", "microsoft", "google", "amazon", "netflix", "facebook",
    "instagram", "whatsapp", "linkedin", "dropbox", "docusign", "office365",
    "office", "outlook", "sharepoint", "onedrive", "chase", "wellsfargo",
    "bankofamerica", "hsbc", "barclays", "santander", "coinbase", "metamask",
    "binance", "steam", "spotify", "adobe", "acrobat", "zoom", "webex", "okta",
]

SUSPICIOUS_WORDS = [
    "login", "signin", "verify", "account", "update", "secure", "confirm",
    "password", "credential", "billing", "invoice", "payment", "unlock",
    "suspended", "verify-account", "recover", "webscr", "auth", "session",
    "banking", "wallet", "seed", "mnemonic", "2fa", "otp", "validate",
]

_LEX_ONLY = set(string.ascii_lowercase + string.digits + ".-")


# ---------------------------------------------------------------------------
# Lexical features
# ---------------------------------------------------------------------------


def shannon_entropy(text: str) -> float:
    """Shannon entropy in bits per character. 0 for empty or uniform text."""
    if not text:
        return 0.0
    counts = Counter(text)
    length = len(text)
    return -sum((c / length) * math.log2(c / length) for c in counts.values())


def registered_domain(host: str) -> str:
    """Best-effort registrable domain.

    Deliberately simple: handles the common two-label public suffixes without
    pulling in the Public Suffix List. Multi-part suffixes are listed explicitly
    so the common cases are right.

    Three cases short-circuit, and all three matter because this runs over a
    malicious-URL corpus where a large share of hosts are bare IPs:

    * an IP host has no registrable domain and no registration date, so it is
      returned unchanged and ``rdap_age`` will correctly decline to look it up;
    * a host with no dot is a single label, not a domain;
    * a malformed host is returned unchanged rather than having its last two
      labels blindly joined -- doing that turned ``216.126.86.152`` into
      ``86.152`` and ``http://1.2.3/`` into ``3``.
    """
    host = (host or "").lower().strip().strip(".")
    if not host:
        return ""
    if _is_ip(host):
        return host
    if "." not in host:
        return host
    labels = host.split(".")
    if any(not label for label in labels):
        return host
    # A TLD is alphabetic (or punycode). If the last label is a number this is
    # an address or a malformed host, not a domain.
    tld = labels[-1]
    if tld.isdigit():
        return host
    if len(parts := labels) >= 3:
        two_label = {"co.uk", "com.au", "co.jp", "co.nz", "co.za", "com.br",
                     "org.uk", "ac.uk", "gov.uk", "com.cn", "co.in", "com.mx"}
        if ".".join(parts[-2:]) in two_label:
            return ".".join(parts[-3:])
    return ".".join(parts[-2:])


def _is_ip(host: str) -> bool:
    candidate = host.strip("[]")
    try:
        ipaddress.ip_address(candidate)
        return True
    except ValueError:
        return False


def extract_features(url: str, domain_age_days: float | None = None) -> dict:
    """Compute every feature for one URL.

    Args:
        url: the full URL.
        domain_age_days: from :func:`rdap_age`, or None if not looked up. A
            missing lookup becomes 9999, which sorts as "very old" and keeps a
            NaN out of the model -- an explicit sentinel beats a missing value.
    """
    raw = url.strip()
    try:
        parsed = urllib.parse.urlsplit(raw if "://" in raw else f"http://{raw}")
        host = (parsed.hostname or "").lower()
    except ValueError:
        parsed, host = None, ""

    path = parsed.path if parsed else ""
    query = parsed.query if parsed else ""

    # Reconstruct the registrable domain from the host, preserving the prefix.
    labels = host.split(".") if host else []
    if _is_ip(host):
        reg = host
        sub = ""
    elif len(labels) >= 2:
        reg = registered_domain(host)
        sub = host[: -(len(reg) + 1)] if host.endswith(reg) else ""
    else:
        reg = host
        sub = ""

    tld = reg.rsplit(".", 1)[-1] if "." in reg else ""
    brand_host = [b for b in BRANDS if b in host]
    brand_sub = [b for b in BRANDS if b in sub]
    brand_path = [b for b in BRANDS if b in path.lower()]

    blob = f"{host}{path}".lower()
    suspicious = [w for w in SUSPICIOUS_WORDS if w in blob]

    age = 9999.0 if domain_age_days is None else float(domain_age_days)

    features = {
        "url_length": float(len(raw)),
        "host_length": float(len(host)),
        "subdomain_depth": float(len(labels) - len(reg.split(".")) if sub else 0),
        "digit_ratio": (sum(c.isdigit() for c in host) / len(host)) if host else 0.0,
        "hyphen_count": float(host.count("-")),
        "special_char_ratio": (
            sum(1 for c in host if c not in _LEX_ONLY) / len(host) if host else 0.0
        ),
        "host_entropy": shannon_entropy(host),
        "path_entropy": shannon_entropy(path),
        "subdomain_entropy": shannon_entropy(sub),
        "tld_risk": RISKY_TLDS.get(tld, 0.0),
        "suspicious_tld": float(tld in RISKY_TLDS),
        "is_ip_host": float(_is_ip(host)),
        "punycode": float("xn--" in host),
        "credential_in_url": float("@" in (parsed.netloc if parsed else "")),
        "nonstandard_port": float(bool(parsed and parsed.port)),
        "shortener": float(reg in SHORTENERS or host in SHORTENERS),
        "brand_in_subdomain": float(bool(brand_sub)),
        "brand_in_path": float(bool(brand_path)),
        "brand_in_host": float(bool(brand_host)),
        "suspicious_words": float(len(suspicious)),
        "path_depth": float(len([p for p in path.split("/") if p])),
        "query_params": float(len([p for p in query.split("&") if p]) if query else 0.0),
        "domain_age_days": age,
        "is_new_domain": float(0 <= age < 30),
        "has_https": float(bool(parsed and parsed.scheme == "https")),
    }
    return features


FEATURE_NAMES = sorted(FEATURE_DOC)


def feature_matrix(urls: list[str], ages: dict[str, float] | None = None
                   ) -> tuple[list[list[float]], list[str]]:
    """Feature matrix for a list of URLs, in :data:`FEATURE_NAMES` order."""
    ages = ages or {}
    rows = []
    for url in urls:
        values = extract_features(url, ages.get(_cache_key(url)))
        rows.append([values[name] for name in FEATURE_NAMES])
    return rows, FEATURE_NAMES


# ---------------------------------------------------------------------------
# RDAP domain age
# ---------------------------------------------------------------------------


def _cache_key(url: str) -> str:
    """Cache on registrable domain, not the full URL.

    Caching per-URL would mean a network call for every path variant of the same
    domain, which is the difference between minutes and hours.
    """
    host = urllib.parse.urlsplit(url if "://" in url else f"http://{url}").hostname or ""
    return registered_domain(host.lower())


def _load_cache() -> dict:
    if CACHE_PATH.exists():
        try:
            return json.loads(CACHE_PATH.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            return {}
    return {}


def _save_cache(cache: dict) -> None:
    CACHE_PATH.parent.mkdir(parents=True, exist_ok=True)
    CACHE_PATH.write_text(json.dumps(cache, indent=0), encoding="utf-8")


def rdap_age(domain: str, timeout: int = RDAP_TIMEOUT) -> float | None:
    """Days since the domain's registration, from live RDAP.

    Returns None when the lookup fails for any reason, including two that are
    routine on a malicious-URL corpus rather than bugs:

    * the host is a bare IP -- an address is not a registered domain, so there
      is no registration date to fetch;
    * the domain no longer resolves in RDAP, which is the normal state of
      affairs for infrastructure that has been seized or taken down.

    rdap.org is used as the bootstrap because it redirects to whichever
    authoritative registry the TLD actually uses, so no per-TLD endpoint list
    is needed.
    """
    if not domain:
        return None
    if _is_ip(domain):
        return None
    url = f"https://rdap.org/domain/{domain}"
    request = urllib.request.Request(
        url,
        headers={"User-Agent": "ai-llm-security-lab/1.0",
                 "Accept": "application/rdap+json"},
    )
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            data = json.load(response)
    except (urllib.error.URLError, OSError, ValueError, json.JSONDecodeError):
        return None

    registered = None
    for event in data.get("events", []):
        if str(event.get("eventAction", "")).lower() in ("registration", "registration action"):
            registered = event.get("eventDate")
            break
    if not registered:
        return None
    try:
        # RDAP dates are ISO 8601; the fractional seconds on some registries
        # are not accepted by fromisoformat on 3.12, so trim them.
        stamp = registered.replace("Z", "+00:00")
        if "." in stamp:
            head, _, tail = stamp.partition(".")
            digits = "".join(c for c in tail if c.isdigit())[:6]
            stamp = f"{head}.{digits}" + ("+00:00" if "+" in tail else "")
        parsed_time = datetime_from_iso(stamp)
    except (ValueError, TypeError):
        return None
    if parsed_time is None:
        return None
    return max(0.0, (time.time() - parsed_time) / 86400.0)


def datetime_from_iso(stamp: str):
    from datetime import datetime

    try:
        return datetime.fromisoformat(stamp).timestamp()
    except ValueError:
        return None


def enrich_with_domain_age(urls: list[str], limit: int | None = None,
                           workers: int = 8, verbose: bool = True
                           ) -> tuple[dict[str, float], dict]:
    """Look up domain age for the unique domains in ``urls``.

    Only the registrable domain is looked up, once, then shared across all paths.
    Results are cached on disk so re-runs are instant.

    Returns:
        (age_by_url, stats)
    """
    cache = _load_cache()
    now = time.time()
    domains = sorted({_cache_key(u) for u in urls if _cache_key(u)})
    if limit:
        domains = domains[:limit]

    fresh = [d for d in domains
             if d not in cache or (now - cache[d].get("_fetched", 0)) > CACHE_TTL]
    if verbose:
        print(f"  {len(domains)} unique domains, {len(fresh)} need a lookup "
              f"({len(domains) - len(fresh)} cached)", flush=True)

    if fresh:
        # Sequential would be ~1s per domain; these are independent I/O calls.
        with ThreadPoolExecutor(max_workers=workers) as pool:
            futures = {pool.submit(rdap_age, d): d for d in fresh}
            done = 0
            for future in as_completed(futures):
                domain = futures[future]
                try:
                    age = future.result()
                except Exception:
                    age = None
                cache[domain] = {"age_days": age, "_fetched": now}
                done += 1
                if verbose and done % 50 == 0:
                    print(f"    looked up {done}/{len(fresh)}", flush=True)
        _save_cache(cache)

    ages: dict[str, float] = {}
    hits = 0
    ip_hosts = 0
    for url in urls:
        key = _cache_key(url)
        if _is_ip(key):
            ip_hosts += 1
        entry = cache.get(key)
        if entry and entry.get("age_days") is not None:
            # Keyed by registrable domain, matching what feature_matrix asks
            # for. Keying by URL meant every path variant of a domain missed.
            ages[key] = entry["age_days"]
            hits += 1

    stats = {
        "unique_domains": len(domains),
        "lookups_performed": len(fresh),
        "cache_hits": len(domains) - len(fresh),
        "domains_with_age": hits,
        "domains_total": len(domains),
        "rdap_success_rate": round(hits / len(domains), 4) if domains else 0.0,
        "urls_ip_hosted": ip_hosts,
        "urls_total": len(urls),
    }
    return ages, stats


def describe(url: str) -> str:
    """Human-readable feature dump, for inspecting individual URLs."""
    ages, _ = enrich_with_domain_age([url], verbose=False)
    values = extract_features(url, ages.get(url))
    lines = [f"{url}", ""]
    for name in FEATURE_NAMES:
        bar = "#" * min(40, int(values[name] * 4)) if values[name] <= 10 else "#" * 40
        lines.append(f"  {name:<24} {values[name]:>10.3f}  {bar}")
    return "\n".join(lines)