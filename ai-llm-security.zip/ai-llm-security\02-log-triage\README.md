# 02 — AI-Assisted Log Triage

Classify and prioritise SIEM alerts, and report honestly on how accurate that
actually is.

```bash
python audit_data.py       # read this first, always
python triage.py           # all three experiments
python triage.py --quick   # 15k rows instead of 60k
```

Dataset: **100,000 real Microsoft Sentinel events**, from
[`darkknight25/Advanced_SIEM_Dataset`](https://huggingface.co/datasets/darkknight25/Advanced_SIEM_Dataset).
Downloaded automatically on first run (~90 MB).

---

## Start with the audit, not the model

This is the part that matters. Run `audit_data.py` before you quote a single
accuracy number, because the obvious task on this dataset is a trap and the
scoring code would never have told you.

### Finding 1 — there is no ground truth

No field labels an event malicious or benign. `severity` is the sensor's own
assessment, with no independent verification anywhere in the dataset. So **no
attack-detection accuracy can be measured here.** Any paper quoting one is
quoting a number about a label that does not exist.

### Finding 2 — the analytic columns are noise

| Column | Observed mean | Uniform would be | Observed std | Uniform would be | Range |
| --- | --- | --- | --- | --- | --- |
| `baseline_deviation` | 1.7374 | 1.75 | 0.7176 | 0.7217 | 0.5–3.0 |
| `entropy` | 4.9608 | 5.00 | 1.7211 | 1.7321 | 2.0–8.0 |

Both are consistent with clean uniform random draws. They look like behavioural
analytics because they have behavioural-analytics names and plausible ranges.
They are decorative. **A model given these features learns nothing.**

### Finding 3 — the obvious task leaks its own answer

`severity` appears verbatim inside `raw_log` in **100.0% of rows** — it is a field
in the CEF header. So "predict severity from the log" is solvable by copying.

## Experiment A — the leak, measured

```
leaky: severity present in raw_log
    accuracy 100.0%   F1 100.0%

scrubbed: severity token removed
    accuracy  21.1%   F1  20.2%

majority-class baseline
    accuracy  21.2%

accuracy attributable to the leak:  +78.9 points
```

**The scrubbed model scores *below* the majority-class baseline.** Not "slightly
worse" — worse than predicting the same class every time. With the leak removed
there is genuinely nothing to learn, because severity was assigned without
reference to the event content.

That is the most transferable result in this project: a 100% score that vanishes
to below-baseline the moment you look properly is what a label leak looks like.
This would pass code review, pass a CI threshold and appear in a slide deck.

## Experiment B — triage model, four ways

Because there is no ground truth, the label is **constructed** from documented,
documented rules — the kind of thing a SOC playbook would plausibly contain
(auth failure bursts, privilege changes, credential access, exfiltration
shapes, malware signals, policy bypass).

```
rows 15,000   positive rate 8.6%   majority-class baseline 91.4%

MODEL                     PREC   RECALL      F1     ACC
------------------------------------------------------
LogisticRegression       1.000    1.000   1.000   1.000
LinearSVC                1.000    1.000   1.000   1.000
RandomForest             0.988    1.000   0.994   0.999
NaiveBayes               0.627    0.944   0.753   0.947
```

**Read the perfect scores as a warning, not a success.** The label was built by
running regexes over the same text the model sees. A model that scores 1.000 has
reproduced my rules exactly — which is the expected result and tells you nothing
about attacks. Naive Bayes failing at 0.627 precision while the linear models hit
1.000 is the same fact seen from another angle: the boundary here is a keyword
boundary, which a generative model nails and a naive one blurs.

For an SOC, **precision is the number that matters** — of the alerts escalated,
how many should have been. Recall of 1.000 with precision 1.000 on a
rule-reproduction task is not a claim about detection.

## Experiment C — what the model is really doing

```
event type alone, no text     F1 0.501   acc 0.829
every rule keyword redacted   F1 0.869   acc 0.975
majority-class baseline       acc 0.914
```

Event type alone gets over half the F1, so the model is partly reading category
structure rather than content.

The second row was meant to be a hard negative and did not fully work. After
redacting the exact rule keywords, F1 only drops to 0.869. That is a real
finding rather than a bug: the dataset's `description` field is templated from
event content, so vocabulary correlated with the rules survives redaction of the
rules themselves. **That is further evidence the data is synthetically
generated**, and that its surface features are recoverable by construction.

## Honest summary of failures

1. **No ground truth, so no detection claim is possible.** This is the headline
   and it is not fixable with better modelling.
2. **The headline metric was a label leak.** +78.9 points of the 100% was free.
3. **The triage scores are circular.** Perfect scores mean "reproduced the
   generating rules".
4. **The analytic features are noise.** Two columns with convincing names and
   no information.
5. **The data is synthetic.** Templated descriptions, uniform severity, uniform
   analytics columns. It is useful for testing a pipeline. It is not evidence
   about real SOCs.
6. **My own redaction in Experiment C leaked.** Replacing rule matches with a
   distinct `REDACTED` token left the *count* of tokens as a near-perfect
   predictor. Fixed by collapsing to a single shared token — and worth stating,
   because it is the same class of mistake as the original leak, made by the
   person who found it.

## What a real deployment needs

- Verified incident labels, ideally from case-management outcomes.
- A leakage check before training: does the target appear in the input?
- Feature provenance: is each column measured, or generated?
- Reporting precision at the escalation threshold, not accuracy.
- Periodic re-measurement, because alert volume and attack patterns both drift.

The code here does the leakage check. It does not have verified labels, so it
cannot do the rest — and says so rather than filling the gap with a number.

## Files

```
02-log-triage/
├── audit_data.py    the audit. run this first.
├── triage.py        three experiments + four models
├── results.json     output from the last run
└── data/siem.jsonl  dataset (downloaded on first run)
```