"""
Data loading and the audit that decides whether this dataset can support any
security claim at all.

Run the audit first, always:

    python audit_data.py

It is the most important file in this project. Everything downstream depends on
what it finds, and what it finds is that the dataset cannot support an
attack-detection claim -- and that the obvious task on it is a label-leakage
trap. Read the output before reading the model results.
"""

from __future__ import annotations

import collections
import itertools
import json
import urllib.request
from pathlib import Path

import numpy as np

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

DATASET_URL = ("https://huggingface.co/datasets/darkknight25/"
               "Advanced_SIEM_Dataset/resolve/main/advanced_siem_dataset.jsonl")
DATASET_NAME = "darkknight25/Advanced_SIEM_Dataset"

DATA_DIR = Path(__file__).resolve().parent / "data"
DATA_FILE = DATA_DIR / "siem.jsonl"
MAX_ROWS = 60_000          # the file has 100k; more is slower and no clearer

SEVERITY_ORDER = ["info", "low", "medium", "high", "critical", "emergency"]

# Fields that carry a severity assessment of their own. Anything derived from
# them is not evidence.
SEVERITY_LEAK_FIELDS = ("severity",)


def ensure_data() -> Path:
    """Download the dataset if it is not already present."""
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    if DATA_FILE.exists() and DATA_FILE.stat().st_size > 1_000_000:
        return DATA_FILE
    print(f"downloading {DATASET_NAME} (~90 MB, once) ...", flush=True)
    urllib.request.urlretrieve(DATASET_URL, DATA_FILE)
    return DATA_FILE


def load(max_rows: int = MAX_ROWS) -> list[dict]:
    """Read up to ``max_rows`` events."""
    path = ensure_data()
    rows: list[dict] = []
    with path.open(encoding="utf-8", errors="replace") as handle:
        for line in itertools.islice(handle, max_rows):
            line = line.strip()
            if not line:
                continue
            try:
                rows.append(json.loads(line))
            except json.JSONDecodeError:
                continue
    return rows


# ---------------------------------------------------------------------------
# The audit
# ---------------------------------------------------------------------------


def audit(rows: list[dict]) -> dict:
    """Establish what this dataset can and cannot tell us.

    Four checks, each of which can invalidate a study:

    1. Is there a ground-truth label at all?
    2. Do the analytic columns carry signal, or are they noise?
    3. Is the label recoverable from the input, which makes the task trivial?
    4. Does the label carry any information beyond a constant?
    """
    report: dict = {"rows": len(rows)}

    # -- 1. ground truth --------------------------------------------------
    severity = collections.Counter(r.get("severity") for r in rows)
    report["severity_distribution"] = dict(severity)
    report["has_ground_truth"] = False
    report["ground_truth_note"] = (
        "No field labels an event malicious or benign. 'severity' is the "
        "sensor's own assessment, not a verified verdict, and the dataset "
        "provides no independent confirmation of it."
    )

    # -- 2. are the analytics columns signal or noise? --------------------
    deviations, entropies = [], []
    for row in rows:
        analytics = row.get("behavioral_analytics")
        if isinstance(analytics, dict):
            if isinstance(analytics.get("baseline_deviation"), (int, float)):
                deviations.append(analytics["baseline_deviation"])
            if isinstance(analytics.get("entropy"), (int, float)):
                entropies.append(analytics["entropy"])

    def uniform_check(values: list[float], low: float, high: float) -> dict:
        if len(values) < 100:
            return {"n": len(values), "verdict": "too few values"}
        array = np.array(values)
        expected_mean = (low + high) / 2
        # Uniform on [low, high) has standard deviation (high-low)/sqrt(12)
        expected_std = (high - low) / np.sqrt(12)
        observed = {
            "n": int(array.size),
            "mean": round(float(array.mean()), 4),
            "expected_mean_if_uniform": round(expected_mean, 4),
            "std": round(float(array.std()), 4),
            "expected_std_if_uniform": round(expected_std, 4),
            "min": round(float(array.min()), 4),
            "max": round(float(array.max()), 4),
        }
        mean_gap = abs(observed["mean"] - expected_mean)
        std_gap = abs(observed["std"] - expected_std)
        observed["looks_uniform"] = mean_gap < 0.15 * abs(expected_std) and std_gap < 0.25 * expected_std
        observed["verdict"] = (
            "consistent with a uniform random draw -- carries no information"
            if observed["looks_uniform"]
            else "deviates from uniform; may carry signal"
        )
        return observed

    report["baseline_deviation"] = uniform_check(deviations, 0.5, 3.0)
    report["entropy"] = uniform_check(entropies, 2.0, 8.0)

    # -- 3. label leakage -------------------------------------------------
    leaked = 0
    for row in rows:
        raw = row.get("raw_log") or ""
        value = row.get("severity")
        if value and f"|{value}|" in raw:
            leaked += 1
    report["severity_leakage"] = {
        "rows_where_severity_appears_in_raw_log": leaked,
        "fraction": round(leaked / len(rows), 4) if rows else 0.0,
        "verdict": (
            "SEVERE LEAKAGE. The label is a substring of the input. Any model "
            "can score near 100% by copying it, and that number means nothing."
            if leaked / max(1, len(rows)) > 0.9 else "no systematic leakage found"
        ),
    }

    # -- 4. does severity carry information at all? -----------------------
    cross = collections.defaultdict(collections.Counter)
    for row in rows:
        cross[row.get("event_type")][row.get("severity")] += 1
    per_type = {}
    for event_type, counter in cross.items():
        total = sum(counter.values())
        top_share = counter.most_common(1)[0][1] / total if total else 0.0
        per_type[event_type] = {
            "n": total,
            "severities_seen": len(counter),
            "most_common": counter.most_common(1)[0],
            "top_share": round(top_share, 4),
        }
    report["severity_by_event_type"] = per_type
    report["severity_is_random"] = all(
        v["top_share"] < 0.25 for v in per_type.values()
    )
    report["severity_note"] = (
        "Severity is spread near-uniformly across levels within every event "
        "type. Whatever generated it was not conditioned on the event content, "
        "so a model can only learn 'which level did the generator pick', which "
        "is not a security-relevant property."
        if report["severity_is_random"] else
        "Severity varies with event type; some conditional signal exists."
    )

    report["usable_for_attack_detection"] = False
    return report


def print_audit(report: dict) -> None:
    rule = "=" * 74
    print(rule)
    print("DATA AUDIT -- what can this dataset actually support?")
    print(rule)
    print(f"rows: {report['rows']:,}")

    print("\n1. GROUND TRUTH")
    print(f"   malicious/benign label present: {report['has_ground_truth']}")
    print(f"   {report['ground_truth_note']}")
    print("   severity distribution:")
    for level, count in sorted(report["severity_distribution"].items(),
                               key=lambda kv: SEVERITY_ORDER.index(kv[0])
                               if kv[0] in SEVERITY_ORDER else 99):
        share = count / max(1, report["rows"])
        bar = "#" * int(share * 40)
        print(f"      {level:<10} {count:>7,}  {share:>6.1%}  {bar}")

    print("\n2. ARE THE ANALYTIC COLUMNS SIGNAL, OR NOISE?")
    for field in ("baseline_deviation", "entropy"):
        stats = report[field]
        if stats.get("n", 0) < 100:
            print(f"   {field}: {stats.get('verdict')}")
            continue
        print(f"   {field}")
        print(f"      n={stats['n']:,}  mean={stats['mean']} "
              f"(uniform would be {stats['expected_mean_if_uniform']})")
        print(f"      std={stats['std']} (uniform would be "
              f"{stats['expected_std_if_uniform']})  "
              f"range=[{stats['min']}, {stats['max']}]")
        print(f"      -> {stats['verdict']}")

    print("\n3. LABEL LEAKAGE")
    leak = report["severity_leakage"]
    print(f"   severity appears inside raw_log: "
          f"{leak['rows_where_severity_appears_in_raw_log']:,} rows "
          f"({leak['fraction']:.1%})")
    print(f"   -> {leak['verdict']}")

    print("\n4. DOES SEVERITY CARRY INFORMATION?")
    for event_type, stats in sorted(report["severity_by_event_type"].items()):
        print(f"   {event_type:<10} {stats['most_common']}  "
              f"top share {stats['top_share']:.1%}  "
              f"({stats['severities_seen']} distinct levels)")
    print(f"   -> {report['severity_note']}")

    print("\n" + rule)
    print("CONCLUSION")
    print(rule)
    print("   This dataset CANNOT support an attack-detection claim:")
    print("     * there is no verified malicious/benign label;")
    print("     * the analytic columns are consistent with uniform noise;")
    print("     * the obvious task leaks its own label from the input.")
    print()
    print("   What it CAN support, honestly reported:")
    print("     * a label-leakage demonstration -- remove the leak and watch")
    print("       accuracy collapse to the majority-class baseline;")
    print("     * a triage tool scored against a CONSTRUCTED, documented label,")
    print("       where accuracy is measured against the rules that defined")
    print("       the label and not against verified reality.")
    print()
    print("   Any accuracy figure quoted from this dataset without these caveats")
    print("   is meaningless. That is the point of this file.")


if __name__ == "__main__":
    print_audit(audit(load()))