# AI and LLM Security — Four Labs

Four security projects built on real data, each measuring what it actually
achieved rather than what it could have claimed.

| # | Project | Headline |
| --- | --- | --- |
| 01 | [LLM prompt injection lab](01-llm-prompt-injection/) | 18/18 attacks compromise an undefended RAG app; 0/18 after the defence stack. A keyword filter stops half. |
| 02 | [AI-assisted log triage](02-log-triage/) | The obvious task leaks its own label: **100.0% → 21.1%**, which is *below* the majority-class baseline. |
| 03 | [Phishing email detector](03-phishing-detector/) | 0.982 in-distribution F1 becomes **0.556 recall on real credential phishing**. 8 of 18 missed. |
| 04 | [Malicious URL detector](04-url-detector/) | 0.994 F1, but domain age applies to **0.4%** of the domains, and the benign class is 240 famous websites. |

---

## The through-line

Every project here was set up to produce a good number, and every one of them
produced a number that needed a caveat large enough to change what you would
conclude:

| What a lazy report would say | What is actually true |
| --- | --- |
| "Our detector achieves 100% accuracy" | The label was a substring of the input. Scrub it and the model scores *below baseline*. |
| "99% F1 phishing detection" | The corpus is bulk spam. On real credential phishing, recall is 56%. |
| "Domain age detects malicious URLs" | It applies to 0.4% of the domains in a live attack feed. |
| "A keyword filter protects the LLM app" | It stops 50%. The structural layers stop the rest. |
| "The triage model scores 1.000 F1" | It reproduced the regexes that defined its own labels. |

None of these is a failure of the work. They are the work.

## Setup

```bash
python -m pip install -r requirements.txt
```

Python 3.12 verified. Only numpy, pandas, scikit-learn and scipy are needed for
the core of 02–04. Projects 01 and 04 need network access; the rest run offline.

**torch / transformers are optional** and only used for the transformer row in
project 03. Project 01 deliberately requires no API key.

## Running everything

```bash
cd 01-llm-prompt-injection && python run_lab.py
cd ../02-log-triage          && python audit_data.py && python triage.py
cd ../03-phishing-detector    && python train.py --quick && python adversarial_eval.py
cd ../04-url-detector        && python build_dataset.py && python train.py
```

Timings on a CPU-only laptop: 01 under a second, 02 about two minutes, 03 about
three minutes with `--quick` and roughly fifteen with the transformer, 04 about
forty seconds including RDAP lookups.

## Data

All four use real data, downloaded on first run.

| Project | Source | Size |
| --- | --- | --- |
| 02 | [`darkknight25/Advanced_SIEM_Dataset`](https://huggingface.co/datasets/darkknight25/Advanced_SIEM_Dataset) — 100,000 Microsoft Sentinel events | 90 MB |
| 03 | [`zefang-liu/phishing-email-dataset`](https://huggingface.co/datasets/zefang-liu/phishing-email-dataset) — 18,650 labelled emails | 50 MB |
| 04 | URLhaus + OpenPhish + Phishing.Database live feeds | 8 MB |
| 01 | hand-authored corpus and attack suite | — |

One candidate dataset was **rejected**: `lixi0029/phishing-mail` has 600 rows of
templated filler — *"Dear client, we need you to update your billing
information."* Passing that off as a public phishing corpus would have been
dishonest, so the 50 MB real corpus was used instead.

## What each project is really about

### 01 — Prompt injection is an architectural property

The target is a RAG assistant that concatenates retrieved documents into the
prompt with nothing marking them as data. Every attack class works, including
indirect injection where **the user is not the attacker** and never finds out.

The measured result that matters: the keyword filter stops 9 of 18, and the
structural layers stop the other 9. Input filtering is necessary and nowhere near
sufficient. Privilege separation — destructive actions simply not being
reachable from model output — is what gets it to zero.

No API key is used. The backend is a deterministic instruction interpreter that
shares the properties that matter (it obeys instructions found anywhere in
context; it is fooled by the same obfuscation a model is) but is not a language
model. The findings are about the architecture.

### 02 — Measure the task before you trust the metric

`audit_data.py` runs first and exists to stop you. It establishes that the
dataset has no ground-truth label, that its behavioural-analytics columns are
consistent with uniform random noise, and that the label is a substring of the
input in 100% of rows.

Then the measurement: **100.0% leaky → 21.1% scrubbed**, against a 21.2%
majority baseline. The leak is worth 78.9 points, and removing it leaves the
model worse than useless.

The triage model that follows scores a perfect 1.000 F1, which is a warning
rather than a success — the label was built by running regexes over the same text
the model reads.

### 03 — In-distribution score and adversarial score are different things

Five classical models plus a transformer, on a real corpus. All land within
0.02 F1, which is itself informative: when classes are that separable, algorithm
choice is not the lever.

Then the same models on 36 hand-authored emails sharing no spam vocabulary with
the training set. Best model's F1 falls from 0.982 to 0.667, and it misses
**8 of 18 real credential-phishing emails**. The misses are the professionally
written ones — a CEO approval request, a legal-hold notice, a supplier thread
where the callback procedure was already followed.

### 04 — The feature everyone cites does not apply to attack URLs

Domain age is implemented for real, via live RDAP, and it works: `github.com`
returns 6,948 days. Applied to a live malicious feed it returns a date for
**0.4%** of domains, because most URLs are IP-hosted and most named domains are
dead.

That is the honest finding, and it is the reason the top features are entropy
and character patterns rather than reputation.

## Cross-project lessons

1. **Check whether the label is in the input.** Cheapest possible check, largest
   possible saving (78.9 points in project 02).
2. **A high score on a task you defined is a tautology.** Both constructed-label
   experiments here scored ~1.000 and learned nothing about security.
3. **Test on data that looks like the real problem.** The single most valuable
   artifact in this suite is the 36-email adversarial set.
4. **Structural controls beat pattern matching.** Filtering stopped half the LLM
   attacks; privilege separation stopped all of them.
5. **Publish the negative results.** The 0.4% domain-age hit rate is more useful
   than a benchmark table would have been.

## Repository layout

```
ai-llm-security/
├── README.md                 this file
├── requirements.txt
├── common/                   shared helpers
├── 01-llm-prompt-injection/  RAG app, 18 attacks, 5 defence layers, OWASP mapping
├── 02-log-triage/            data audit + triage model
├── 03-phishing-detector/     model comparison + adversarial evaluation
└── 04-url-detector/          feature engineering + live RDAP
```

## Limitations

Stated once, here, rather than repeated in four places.

- **No LLM API is used anywhere.** Project 01's conclusions are architectural.
  They would need re-running against a real model to say anything about one.
- **The adversarial set in 03 is mine.** 36 hand-written emails. The direction
  and rough size of the gap are robust; the exact figures are not authoritative.
- **Two datasets are synthetic.** 02's SIEM events are generated, 04's benign
  class is curated. Both are stated in their own READMEs.
- **No temporal splits anywhere.** Every random split here lets near-duplicates
  span train and test, which inflates results equally across all four projects.
- **No production threat model.** These are labs. A real deployment faces
  adversarial adaptation, and a detector optimised on static feeds will degrade.

## Legal and ethical note

The URL detector reads public blocklists and RDAP registration data. It does not
fetch or execute anything from the URLs it classifies, and it makes no attempt
to reach any infrastructure.

Project 01's attack payloads are written to demonstrate recognition, not to be
sent. Nothing in this repository is a working lure.