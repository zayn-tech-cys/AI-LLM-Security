"""
Train and evaluate the malicious-URL detector.

    python train.py                      # full run, with live RDAP lookups
    python train.py --no-rdap            # lexical + structural only, instant
    python train.py --inspect <url>      # feature dump for one URL

Domain age is looked up live via RDAP and cached, so the first run costs a
network round trip per unique domain and every run after that is instant.
"""

from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

import numpy as np
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (accuracy_score, classification_report, confusion_matrix,
                             f1_score, precision_score, recall_score)
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.tree import DecisionTreeClassifier

from build_dataset import load
from features import (FEATURE_DOC, describe, enrich_with_domain_age, feature_matrix)

HERE = Path(__file__).resolve().parent
RULE = "=" * 76


def build_models() -> dict:
    # The features are on wildly different scales: entropy and ratios sit in
    # 0-5, while url_length runs to thousands and domain_age_days to ~11,000.
    # Trees do not care; a linear model does, and lbfgs fails to converge
    # without scaling. A Pipeline keeps the scaler inside the fitted object so
    # it cannot leak between train and test.
    def scaled(estimator):
        return Pipeline([
            ("scale", StandardScaler()),
            ("clf", estimator),
        ])

    return {
        "DecisionTree(d=8)": DecisionTreeClassifier(max_depth=8, random_state=0,
                                                     class_weight="balanced"),
        "LogisticRegression": scaled(LogisticRegression(max_iter=2000, C=1.0,
                                                       class_weight="balanced")),
        "RandomForest": RandomForestClassifier(n_estimators=300, max_depth=14,
                                               n_jobs=-1, random_state=0,
                                               class_weight="balanced"),
        "GradientBoosting": GradientBoostingClassifier(n_estimators=200, max_depth=4,
                                                       random_state=0),
    }


def importance_report(model, feature_names, top: int = 10) -> list[tuple]:
    if not hasattr(model, "feature_importances_"):
        return []
    weights = model.feature_importances_
    pairs = sorted(zip(feature_names, weights), key=lambda kv: kv[1], reverse=True)
    return pairs[:top]


def main() -> int:
    parser = argparse.ArgumentParser(description="Malicious URL detector")
    parser.add_argument("--no-rdap", action="store_true",
                        help="skip domain-age lookups (offline, instant)")
    parser.add_argument("--rdap-limit", type=int, default=700,
                        help="max unique domains to look up (default 700)")
    parser.add_argument("--inspect", metavar="URL",
                        help="print the feature vector for one URL and exit")
    parser.add_argument("--json", default="results.json")
    args = parser.parse_args()

    if args.inspect:
        print(describe(args.inspect))
        return 0

    print(RULE)
    print("MALICIOUS URL DETECTOR")
    print("Features: lexical + structural + live RDAP domain age")
    print(RULE)

    records = load()
    if not records:
        print("\nno dataset. run: python build_dataset.py")
        return 2

    urls = [r["url"] for r in records]
    labels = np.array([r["label"] for r in records])
    sources = [r["source"] for r in records]
    print(f"\n{len(urls):,} URLs   malicious {labels.sum():,}   "
          f"benign {(1 - labels).sum():,}")
    for source in sorted(set(sources)):
        count = sum(1 for s in sources if s == source)
        print(f"   {source:<18} {count:,}")

    # ---- feature engineering -------------------------------------------
    ages: dict[str, float] = {}
    rdap_stats: dict = {}
    if not args.no_rdap:
        print("\nlooking up domain registration dates via RDAP ...")
        started = time.perf_counter()
        ages, rdap_stats = enrich_with_domain_age(urls, limit=args.rdap_limit)
        print(f"  {rdap_stats['domains_with_age']:,}/{rdap_stats['domains_total']:,} "
              f"domains returned a registration date "
              f"({rdap_stats['rdap_success_rate']:.1%}) in "
              f"{time.perf_counter() - started:.0f}s")
        if rdap_stats["rdap_success_rate"] < 0.5:
            print("  Low hit rate, and that is the finding rather than a fault:")
            print("    most of these domains are dead, seized or already taken")
            print("    down, so no registry still publishes a date for them; and")
            print(f"    {rdap_stats['urls_ip_hosted']:,} URLs are IP-hosted, where")
            print("    'no registered domain' is itself a malicious signal.")

    matrix, names = feature_matrix(urls, ages)
    X = np.array(matrix, dtype=float)
    y = labels

    print(f"\n{len(names)} features computed")
    if not ages:
        print("  (domain_age_days is the 9999 sentinel throughout -- the model")
        print("   will learn to ignore it, and the numbers below understate what")
        print("   the feature is worth in production)")

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42, stratify=y
    )
    print(f"train {len(X_train):,}   test {len(X_test):,}")

    results = []
    for name, model in build_models().items():
        started = time.perf_counter()
        model.fit(X_train, y_train)
        elapsed = time.perf_counter() - started
        predicted = model.predict(X_test)
        results.append({
            "model": name,
            "precision": precision_score(y_test, predicted, zero_division=0),
            "recall": recall_score(y_test, predicted, zero_division=0),
            "f1": f1_score(y_test, predicted, zero_division=0),
            "accuracy": accuracy_score(y_test, predicted),
            "confusion": confusion_matrix(y_test, predicted).tolist(),
            "seconds": round(elapsed, 1),
            "_model": model,
        })
        print(f"  {name:<22} {elapsed:>5.1f}s")

    results.sort(key=lambda r: r["f1"], reverse=True)

    print("\n" + RULE)
    print("RESULTS")
    print(RULE)
    header = f"  {'MODEL':<22}{'PREC':>8}{'RECALL':>9}{'F1':>8}{'ACC':>8}{'SECS':>8}"
    print(header)
    print("  " + "-" * (len(header) - 2))
    for row in results:
        print(f"  {row['model']:<22}{row['precision']:>8.3f}{row['recall']:>9.3f}"
              f"{row['f1']:>8.3f}{row['accuracy']:>8.3f}{row['seconds']:>8.1f}")
    print(f"\n  majority-class baseline accuracy: {max((1 - y).mean(), y.mean()):.3f}")

    best = results[0]
    print(f"\n  best: {best['model']}   confusion [[tn fp][fn tp]] = {best['confusion']}")
    print(classification_report(y_test, best["_model"].predict(X_test),
                                target_names=["benign", "malicious"],
                                digits=3, zero_division=0))

    # ---- which features actually matter -------------------------------
    ranked = importance_report(best["_model"], names, top=12)
    if ranked:
        print(RULE)
        print("TOP FEATURES (by importance)")
        print(RULE)
        top_weight = ranked[0][1] or 1.0
        for name, weight in ranked:
            bar = "#" * int(weight / top_weight * 40)
            doc = FEATURE_DOC.get(name, "")
            print(f"  {name:<24}{weight:>7.3f}  {bar}")
            print(f"      {doc}")

    # ---- what the honest caveats are ----------------------------------
    print("\n" + RULE)
    print("WHAT THESE NUMBERS DO AND DO NOT MEAN")
    print(RULE)
    print("  DO mean: a decision tree on hand-crafted URL features separates")
    print("         these particular URLs well.")
    print()
    print("  DO NOT mean any of the following, all of which are common:")
    print("   * the benign class is 240 curated sites, all large and famous.")
    print("     The model has learned 'not one of the 50 biggest websites',")
    print("     which is not a reusable property. A realistic benign set needs")
    print("     long-tail sites, and this model would flag a great many of them.")
    print("   * the malicious class is mostly malware distribution (urlhaus) and")
    print("     community-reported phishing domains, which are trivially easy:")
    print("     they have keyword-stuffed hosts and brand names.")
    print("   * no URLs are actually fetched. Nothing here checks what a URL")
    print("     serves, so a domain that is benign now and malicious tomorrow")
    print("     is labelled by whatever the feed said today.")
    print("   * domain age is computed for a capped sample of unique domains,")
    print("     and age is the single strongest real-world signal -- so these")
    print("     numbers understate what the full feature set would achieve.")
    print()

    serialisable = [{k: v for k, v in row.items() if k != "_model"}
                    for row in results]
    (HERE / args.json).write_text(
        json.dumps({"n": len(urls), "rdap": rdap_stats, "results": serialisable},
                   indent=2, default=float), encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())