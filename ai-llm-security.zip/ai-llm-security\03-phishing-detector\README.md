# 03 — Phishing Email Detector

Train several models on a public phishing corpus, compare them, and measure how
much the headline score is actually worth.

```bash
python train.py                # full comparison, incl. transformer
python train.py --quick        # 6,000 rows, classical models only
python adversarial_eval.py     # where the winner actually fails
python adversarial_eval.py --show-errors
```

Dataset: **18,650 real labelled emails** from
[`zefang-liu/phishing-email-dataset`](https://huggingface.co/datasets/zefang-liu/phishing-email-dataset)
— 11,322 "Safe Email", 7,328 "Phishing Email". Downloaded automatically on first
run (~50 MB).

---

## Read this before quoting any number

The two classes in this corpus are **bulk spam** and **ordinary email**, not
*credential phishing* and *legitimate business email*.

Inspecting samples:

| Class | What is actually in it |
| --- | --- |
| "Phishing Email" | Advance-fee fraud ("I am your hot lil horny toy", Nigerian prince), adult mail. No credential harvesting. |
| "Safe Email" | Enron business and personal mail, lowercased and tokenised. |

Neither class resembles a targeted business email compromise. So a high score
here means **"this model separates bulk spam from ordinary email"** — which is a
useful and honest result, but not phishing detection performance.

`normalise_subject()` strips URLs and email addresses before training. They are
the strongest artefact in this corpus — the spam class is full of them — and
leaving them in means every model scores well by counting URLs rather than
reading English.

## In-distribution comparison

6,000 rows, majority-class baseline 0.612:

```
MODEL                        PREC  RECALL     F1    ACC
---------------------------------------------------------------
LinearSVC                   0.981   0.981  0.981  0.985
LogisticRegression          0.981   0.976  0.978  0.983
ComplementNB                0.978   0.951  0.964  0.973
RandomForest                0.950   0.974  0.962  0.970
MultinomialNB               0.986   0.931  0.958  0.968
```

All five land within 0.02 F1 of each other. On a separable task with 60k features
that is expected, and it is itself informative: **model choice barely matters
when the classes are this easy to separate.** If swapping a naive Bayes for a
linear SVM changes nothing, the difficulty is in the data, not the algorithm.

### The transformer

`train.py` also fine-tunes `distilbert-base-uncased` (1 epoch, CPU, ~10 min).
It is **excluded from the quick run** because it dominates the runtime and does
not change the conclusion. Enable with the full run.

Expectation, stated before running it: on this corpus a transformer will land
near the linear models, for the same reason. It is included because the brief
asked for the comparison, and the honest finding is that the architectural
difference does not help when the task is easy.

## Adversarial evaluation — the real result

`adversarial_eval.py` scores the same models on 36 hand-authored emails that
share no spam vocabulary with the training corpus: 18 realistic credential-phishing
messages (mailbox-quota lures, payroll bank-detail changes, MFA re-enrolment,
legal-hold notices) and 18 legitimate business emails (meeting notes, contract
reviews, quarterly results, building works).

```
MODEL                  IN-DIST F1  ADV PREC  ADV REC  ADV F1   DROP
-----------------------------------------------------------------
LinearSVC                   0.982     0.833    0.556   0.667  0.316
LogisticRegression          0.980     0.769    0.556   0.645  0.334
ComplementNB                0.975     0.750    0.500   0.600  0.375
RandomForest                0.963     0.750    0.500   0.600  0.363
MultinomialNB               0.973     0.700    0.389   0.500  0.473

best: LinearSVC   confusion [[tn fp][fn tp]] = [[17, 2], [8, 10]]
  false positives (business mail flagged):  2 / 18
  false negatives (phishing not flagged):  8 / 18
```

**A model with 98.2% in-distribution F1 misses 8 of 18 real credential-phishing
emails — 56% recall.**

Run `--show-errors` to see which ones. The misses are the professionally-written
ones: a CEO approval request, a legal-hold notice, a supplier payment thread with
the callback procedure already followed. Exactly the emails a human analyst
would be most annoyed to see slip through.

This is the whole project in one table. The in-distribution score and the
adversarial score are different measurements of different things, and only the
second answers the question a mail filter is deployed to answer.

## Honest summary of failures

1. **The headline score does not generalise.** 0.982 → 0.667 on data that looks
   like the actual problem.
2. **The label does not mean what the task name says.** Bulk spam, not
   credential phishing.
3. **The hard half is the false-negative half.** 8 of 18 credential phishing
   emails passed. A filter with high precision and poor recall is worse than
   useless — it creates confidence without protection.
4. **Model choice is not the lever.** All five classical models are within 0.02
   F1. Data quality dominates algorithm selection.
5. **False positives are the cost users feel.** 2 of 18 legitimate business
   emails flagged. In a real deployment that is the metric that decides whether
   users disable the filter, and it is under-weighted in most published work.
6. **The adversarial set is mine, not an independent benchmark.** 36 emails,
   hand-written, could be argued with. The direction and rough size of the gap
   are robust; the exact figures are not authoritative.
7. **No temporal or author split.** The random split lets the same sender appear
   in train and test, which inflates every number here equally. A split by
   sender would be the minimum honest design.

## What would actually improve this

- Train on real credential-phishing corpora, not bulk spam.
- Add URL reputation and sender-authentication features (SPF/DKIM/DMARC results,
  reply-to divergence, display-name vs domain mismatch). Most of the signal in
  credential phishing is structural, not lexical, and this corpus has no such
  fields.
- Split by sender and by time, not randomly.
- Tune the threshold for the operating point you want. At 0.83 precision the
  filter is already aggressive; most deployments trade the other way.
- Evaluate with the sender's own historical base rate, which dominates F1.

## Files

```
03-phishing-detector/
├── train.py                model comparison, optional transformer
├── adversarial_eval.py     the failure analysis that matters
├── results.json            in-distribution results
├── adversarial_results.json
└── data/Phishing_Email.csv  dataset (downloaded on first run)
```