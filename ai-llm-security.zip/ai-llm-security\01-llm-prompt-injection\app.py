"""
The RAG assistant, in its deliberately vulnerable form.

The vulnerability is architectural, not a bug in a line of code:

    retrieved text  ->  same channel as instructions  ->  model with tools

Three properties make it exploitable, and each is a common real-world mistake:

1. **No trust boundary between instructions and data.** Retrieved documents are
   concatenated into the prompt with no marker that says "this is data".
2. **The model holds secrets it must not disclose.** A system prompt and an API
   key are in the same context the model will be asked about.
3. **The model can take actions.** Anything it can be talked into doing is
   reachable by whoever writes the retrieved text.

:class:`HardenedAssistant` adds the three defences and is in ``defenses.py``,
so the two can be compared on identical attacks.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from knowledge_base import retrieve
from llm_backend import DeterministicLLM, LLMResponse


@dataclass
class Citation:
    doc_id: str
    title: str
    score: float


@dataclass
class Turn:
    """One exchange, with the detail the lab needs to grade it."""

    question: str
    response: LLMResponse
    citations: list[Citation] = field(default_factory=list)
    retrieved_poisoned: bool = False
    blocked: bool = False
    block_reason: str = ""

    def to_dict(self) -> dict:
        return {
            "question": self.question,
            "response": self.response.to_dict(),
            "citations": [c.__dict__ for c in self.citations],
            "retrieved_poisoned": self.retrieved_poisoned,
            "blocked": self.blocked,
            "block_reason": self.block_reason,
        }


class VulnerableAssistant:
    """A RAG assistant with no defences. This is the 'before' picture."""

    def __init__(self, llm: DeterministicLLM | None = None, top_k: int = 4) -> None:
        self.llm = llm or DeterministicLLM()
        self.top_k = top_k
        self.history: list[Turn] = []

    def ask(self, question: str, include_poisoned: bool = True,
            tool_execution: bool = True) -> Turn:
        """Answer a question.

        Args:
            question:         what the user asked.
            include_poisoned: whether the corpus may contain poisoned documents.
                              Direct attacks are tested against the clean corpus
                              so that the payload being measured is the attacker's
                              own, not a poison document that happened to be
                              retrieved alongside it. Indirect attacks depend on
                              the poison and set this True.
            tool_execution:   whether a model-initiated action actually runs. Set
                              False to measure whether the model was *talked into*
                              the request, separately from whether the app would
                              actually perform it.
        """
        hits = retrieve(question, self.top_k, include_poisoned)

        # THE FLAW, in one line. Retrieved text is concatenated into the prompt
        # with nothing distinguishing it from the user's instruction. A model
        # cannot tell the difference, so a model that obeys will obey this too.
        context = "\n\n".join(doc.text for doc, _ in hits)

        response = self.llm.generate(question, context, tools_allowed=tool_execution)

        turn = Turn(
            question=question,
            response=response,
            citations=[
                Citation(d.doc_id, d.title, s) for d, s in hits
            ],
            retrieved_poisoned=any(d.poisoned for d, _ in hits),
        )
        self.history.append(turn)
        return turn

    def reset(self) -> None:
        """Clear conversation memory. Also clears injected instructions."""
        self.llm = DeterministicLLM()
        self.history.clear()

    # -- reporting ---------------------------------------------------------

    @property
    def attack_success_rate(self) -> float:
        if not self.history:
            return 0.0
        return sum(t.response.obeyed_injection for t in self.history) / len(self.history)

    @property
    def secret_leak_rate(self) -> float:
        if not self.history:
            return 0.0
        return sum(t.response.leaked_secret for t in self.history) / len(self.history)

    @property
    def tool_calls(self) -> list[str]:
        return [t.response.invoked_tool for t in self.history if t.response.invoked_tool]

    def report(self) -> dict:
        return {
            "turns": len(self.history),
            "injections_obeyed": sum(t.response.obeyed_injection for t in self.history),
            "secrets_leaked": sum(t.response.leaked_secret for t in self.history),
            "tool_calls": self.tool_calls,
            "attack_success_rate": self.attack_success_rate,
            "secret_leak_rate": self.secret_leak_rate,
        }


def run_scenario(assistant, question: str) -> Turn:
    """Convenience wrapper so the lab scripts read cleanly."""
    return assistant.ask(question)