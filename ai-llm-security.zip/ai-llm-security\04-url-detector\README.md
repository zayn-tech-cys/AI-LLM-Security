# 04 — Malicious URL / Domain Detector

Extracts domain age, entropy and character-pattern features from URLs, then
builds a model that flags suspicious ones.

```bash
python build_dataset.py            # fetch live feeds, build the labelled set
python train.py                    # with live RDAP domain-age lookups
python train.py --no-rdap          # offline, instant
python train.py --inspect <url>    # feature dump for one URL
```

Needs network access for the feeds and for RDAP. Everything else is offline.

---

## Features

23, in three groups. Each is defined in `features.py` under `FEATURE_DOC`.

**Lexical** — `url_length`, `host_length`, `digit_ratio`, `hyphen_count`,
`special_char_ratio`, `host_entropy`, `path_entropy`, `subdomain_entropy`

**Structural** — `subdomain_depth`, `is_ip_host`, `punycode`,
`credential_in_url` (the `@` trick), `nonstandard_port`, `shortener`,
`tld_risk`, `suspicious_tld`, `brand_in_host`, `brand_in_subdomain`,
`brand_in_path`, `suspicious_words`, `path_depth`, `query_params`, `has_https`

**Reputation** — `domain_age_days`, `is_new_domain`, both from **live RDAP**
registration data via `rdap.org`, cached to disk.

### Domain age is a real network feature

`rdap_age()` queries `rdap.org`, which bootstraps to whichever authoritative
registry the TLD uses, so no per-TLD endpoint list is needed. It works:

```
$ python train.py --inspect https://github.com/
  domain_age_days        6947.83  ########################################
  is_new_domain             0.00
```

Lookups are cached on registrable domain, not full URL, so every path variant of
a domain costs one lookup. 500 domains take about 15 seconds with 8 workers.

---

## The honest finding: domain age barely applies to attack URLs

```
500 unique domains looked up
  2 returned a registration date   (0.4%)
  715 URLs are IP-hosted
```

**Only 0.4%.** And this is not a bug — the same code returns 6,948 days for
`github.com`. It is the nature of the data:

- Most URLs in these feeds are **bare IP addresses**. An address is not a
  registered domain, so there is no registration date to fetch. This is itself
  a signal, and `is_ip_host` captures it.
- Most named domains in these feeds are **dead** — seized, sinkholed, or taken
  down. Registries stop publishing data for them.

That is a real operational lesson. Domain age is the strongest single feature in
*published research on phishing URLs*, and it is useless against infrastructure
that is already dead or never had a domain. Any claim that a URL detector is
"powered by domain age" should be checked against a live feed before it is
repeated.

## Results

2,340 URLs: 1,100 malicious (URLhaus 900, OpenPhish 300, Phishing.Database 900,
deduplicated to 1,100) and 240 curated benign. Majority baseline 0.897.

```
MODEL                     PREC   RECALL      F1    ACC
---------------------------------------------------------
GradientBoosting         0.998    0.990   0.994  0.990
DecisionTree(d=8)        1.000    0.985   0.992  0.986
RandomForest             0.998    0.985   0.991  0.985
LogisticRegression       0.996    0.954   0.975  0.956

best: GradientBoosting   confusion [[tn fp][fn tp]] = [[59, 1], [5, 520]]
```

Top features by importance:

```
digit_ratio   0.367   Fraction of digits in the host
path_entropy  0.366   Entropy of the path
host_length   0.074   Registrable-domain length
host_entropy  0.051   Shannon entropy of the host
hyphen_count  0.042   Hyphens in the host
```

Entropy features dominate, which matches how this attack actually works:
generated hosts and redirect paths are high-entropy, real brand domains are not.

## Honest summary of failures

1. **The 0.994 is inflated and should not be quoted.** The benign class is 240
   curated sites — all large, famous, and hand-picked. The model has largely
   learned *"not one of the fifty biggest websites"*. That is not a reusable
   property. Against a realistic long-tail benign set it would flag a great many
   legitimate sites, and the benign-class precision of 0.922 is the first hint of
   that.
2. **The malicious class is easy.** Community-reported phishing domains have
   keyword-stuffed hosts and brand names in them. A decision tree finds that in
   seconds. Real targeted attacks do not look like this.
3. **Domain age contributes nothing here** (0.4% hit rate). The feature is
   correct; the data defeats it.
4. **No URL is ever fetched.** Nothing here checks what a page actually serves,
   so a domain's label is whatever the feed said on the day it was pulled.
5. **No temporal holdout.** A random split lets the same domain appear in train
   and test, which inflates everything equally. A date-based split is the honest
   design.
6. **The benign class is 10% of the data.** Class weighting keeps the metrics
   interpretable, but a real deployment faces a far more skewed ratio.
7. **My own `registered_domain()` was wrong first.** It turned
   `216.126.86.152` into `86.152` and turned IP-host lookups into garbage keys,
   which is why the first RDAP run reported 0.2% success on a bug rather than on
   dead domains. Fixed, and the corrected 0.4% is the real figure. Worth stating
   because it nearly made a real finding look like a fake one.

## What would make this real

- A benign set with genuine long-tail: small business sites, personal blogs,
  regional domains. This is the single biggest gap.
- Fetch-and-classify: what the URL serves, redirected to where, what
  certificate it presents.
- Time-based splits, with a gap, to test on genuinely future domains.
- Reputation features that survive takedown: passive DNS history, certificate
  transparency log age, ASN and hosting-provider reputation.
- Calibration, not just ranking — a detector that cannot say *how sure* is
  unusable in a blocking path.

## Files

```
04-url-detector/
├── features.py     23 features + RDAP domain-age client with disk cache
├── build_dataset.py  live feeds (URLhaus, OpenPhish, Phishing.Database) + curated benign
├── train.py        four models, feature importances, honest caveats
├── results.json
└── data/
    ├── urls.json       labelled URL set
    └── rdap_cache.json registration dates, cached
```